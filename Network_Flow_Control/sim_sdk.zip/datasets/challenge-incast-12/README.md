## 数据集：challenge-incast-12

一个小规模 incast 压测数据集，用于专门考察接收端重排、拥塞控制收敛与小流截止时间保护能力。

### 1. 拓扑结构

- **节点规模**：8 个 host + 4 个交换机，总计 **12 个节点**。
- **层次结构**：
  - 接入层：`H0~H3 -> SW8`，`H4~H7 -> SW9`
  - 汇聚层：`SW8/SW9 -> SW10/SW11`
- **链路参数**：
  - Host–Switch：`10 Gbps`，`2 us`
  - Switch–Switch：`10 Gbps`，`4 us`
- **缓冲区**：全局默认 host/switch 均为 `1 MiB`。

拓扑示意：

```mermaid
flowchart TB
  H0(H0) --> S8[S8]
  H1(H1) --> S8
  H2(H2) --> S8
  H3(H3) --> S8

  H4(H4) --> S9[S9]
  H5(H5) --> S9
  H6(H6) --> S9
  H7(H7) --> S9

  S8 --> S10[S10]
  S8 --> S11[S11]
  S9 --> S10
  S9 --> S11
```

### 2. 流量设计（traffic.csv）

格式：

```text
FlowID,SrcNode,DstNode,SizeBytes,StartTimeUs,Priority,DeadlineUs
```

（`StartTimeUs` / `DeadlineUs` 为微秒，与仿真时间轴一致。）

特征：

- 前 7 条 3 MiB 级流在 `t=0` 同时打向 `H7`，形成明显 incast；
- 之后叠加 3 条 1 MiB 级中小流，考察拥塞背景下的 tail latency；
- 优先级覆盖 50~90，deadline 较紧（约 1.5~2.0 s，见 `traffic.csv` 中 `DeadlineUs`）。

### 3. 重点考察

- **Incast 稳定性**：窗口是否会同时暴涨导致大规模排队与超时。
- **接收端策略**：乱序重排、缓冲腾挪与按序交付推进是否高效。
- **截止时间敏感性**：高优先级和短 deadline 流在拥塞下是否仍能完成。
