## 数据集：leaf-spine-32

一个典型的两层 Leaf-Spine 拓扑，用于考察选路与 ECMP 负载均衡能力。

### 1. 拓扑结构

- **节点规模**：16 个 host，8 个 ToR（Leaf），4 个 Spine，总计 28 个节点。
- **节点类型与编号**：
  - Host：`H0~H15` → 节点 `0~15`
  - ToR：`T0~T7` → 节点 `16~23`（每个 Pod 有 2 个 ToR）
  - Spine：`S0~S3` → 节点 `24~27`
- **链路参数**：
  - Host–ToR：`10 Gbps`，`2 us` 时延
  - ToR–Spine：`10 Gbps`，`4 us` 时延
- 所有节点的缓冲区大小通过 `topology.json` 中的 `global_config.default_host_buffer_size_bytes` / `default_switch_buffer_size_bytes` 统一设为 **1 MiB**。

拓扑示意（Leaf-Spine）如下：

```mermaid
flowchart TB
  subgraph Pod0
    H0(H0) --- T0[T0]
    H1(H1) --- T0
    H2(H2) --- T1[T1]
    H3(H3) --- T1
  end

  subgraph Pod1
    H4(H4) --- T2[T2]
    H5(H5) --- T2
    H6(H6) --- T3[T3]
    H7(H7) --- T3
  end

  subgraph Pod2
    H8(H8) --- T4[T4]
    H9(H9) --- T4
    H10(H10) --- T5[T5]
    H11(H11) --- T5
  end

  subgraph Pod3
    H12(H12) --- T6[T6]
    H13(H13) --- T6
    H14(H14) --- T7[T7]
    H15(H15) --- T7
  end

  subgraph Spine
    S0[S0]
    S1[S1]
    S2[S2]
    S3[S3]
  end

  %% ToR 全连接到所有 Spine
  T0 --- S0
  T0 --- S1
  T0 --- S2
  T0 --- S3

  T1 --- S0
  T1 --- S1
  T1 --- S2
  T1 --- S3

  T2 --- S0
  T2 --- S1
  T2 --- S2
  T2 --- S3

  T3 --- S0
  T3 --- S1
  T3 --- S2
  T3 --- S3

  T4 --- S0
  T4 --- S1
  T4 --- S2
  T4 --- S3

  T5 --- S0
  T5 --- S1
  T5 --- S2
  T5 --- S3

  T6 --- S0
  T6 --- S1
  T6 --- S2
  T6 --- S3

  T7 --- S0
  T7 --- S1
  T7 --- S2
  T7 --- S3
```

### 2. 流量设计（traffic.csv）

文件格式（时间与仿真器一致，单位为**微秒**）：

```text
FlowID,SrcNode,DstNode,SizeBytes,StartTimeUs,Priority,DeadlineUs
```

当前定义了 12 条流，总流量约 **60 MiB**，包含大流和小流，起始时间错开，权重在 30–80 之间：

```text
FlowID,SrcNode,DstNode,SizeBytes,StartTimeUs,Priority,DeadlineUs
2001,0,12,8388608,0,80,4000000
2002,1,13,8388608,0,80,4000000
2003,4,8,4194304,500000,70,4000000
2004,5,9,4194304,500000,70,4000000
2005,2,10,2097152,1000000,60,3000000
2006,3,11,2097152,1000000,60,3000000
2007,6,14,1048576,1500000,50,3000000
2008,7,15,1048576,1500000,50,3000000
2009,0,7,2621440,2000000,40,3000000
2010,8,5,2621440,2000000,40,3000000
2011,9,2,1310720,2500000,30,3000000
2012,10,3,1310720,2500000,30,3000000
```

### 3. 考察点

- **ECMP 与多路径负载均衡**：
  - 相同 Pod 间、跨 Pod 间的流都可以通过多条 Spine 链路转发；
  - 优秀的策略应能在 `ctx.get_next_hops(dst)` 返回的候选端口上做哈希或按队列长度选择，避免单一 spine 过载。

- **大流 vs 小流共存**：
  - 前几条大流（8 MiB 级）在早期占用大量带宽；
  - 后续到来的中小流在同一瓶颈下能否获得较好的 FCT，是评分的关键。

- **对称流量与非对称流量混合**：
  - 包含对称流（如 4↔8 方向上的流）和“热点”流（如指向 H7/H15 的流），有利于测试策略是否能避免将流过多集中在部分 ToR/Spine 组合上。

