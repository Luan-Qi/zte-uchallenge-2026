"""
ECMP + 乱序重排 Demo 策略

目标：
- Host 侧：仍然是“简单一次性发完”的发送逻辑，但在接收端正确处理乱序：
  - 当前包若按序可交付则直接交付；
  - 否则放入接收缓冲，并在缓冲中尽可能继续推进按序前缀。
- Switch 侧：在存在多条 next-hop 时按端口当前使用量做 per-packet ECMP，
  让单条流也能并行占用多条链路，从而提升实际吞吐，接近 ideal FCT。

不实现 ACK、重传或拥塞控制，仅依赖链路不丢包的前提。
"""

from typing import Dict, List, Optional, Union

from sim_api import (
    ControlPacketSpec,
    DataPacketSpec,
    HostContext,
    HostInitInfo,
    HostStrategy,
    LinkId,
    MAX_PAYLOAD,
    PacketId,
    PacketView,
    SwitchContext,
    SwitchInitInfo,
    SwitchStrategy,
)


class _SimpleFlowState:
    """极简 per-flow 状态：只记录发送进度。"""

    def __init__(self, total_size: int):
        self.total_size = total_size
        self.next_seq: int = 0  # 下一个要发送的字节序列号

    @property
    def remaining(self) -> int:
        return max(0, self.total_size - self.next_seq)


class MyHostStrategy(HostStrategy):
    """
    Host 策略：
    - 源 host：按顺序把所有流的数据发完，不发送控制包、不做重传；
    - 目的 host：使用接收缓冲做乱序重排，尽可能交付最长按序前缀。
    - 入缓冲前：若剩余空间不足，按接收顺序丢弃缓冲中最早进入的包，直至能容纳当前包。
    """

    def __init__(self):
        self._flows: Dict[int, _SimpleFlowState] = {}

    def on_sim_start(self, init: HostInitInfo) -> None:
        """本策略不依赖静态拓扑；保留空实现以兼容新接口。"""
        pass

    def _ensure_rx_space_for(self, pkt: PacketView, ctx: HostContext) -> None:
        """
        接收缓冲按完整 DATA 包 size（头+payload）计费，与内核一致。
        空间不足时丢弃最早入缓冲的包，直到剩余 >= 当前包 size。
        """
        need = pkt.size
        while ctx.get_rx_buffer_remaining() < need:
            buf = ctx.get_received_packets()
            if not buf:
                break
            ctx.drop_packet_in_buffer(buf[0].packet_id)

    def on_flow_arrival(
        self,
        flow_id: int,
        dst_node: int,
        size_bytes: int,
        priority: int,
        deadline_us: float,
        ctx: HostContext,
    ) -> None:
        # 新流：仅记录总大小，从 0 开始顺序发送
        self._flows[flow_id] = _SimpleFlowState(total_size=size_bytes)

    def on_link_ready(self, ctx: HostContext) -> Optional[Union[DataPacketSpec, ControlPacketSpec]]:
        """
        唯一出链路空闲时：
        - 在所有仍有剩余数据的流中，按 flow_id 升序选择第一条；
        - 发送一个最大为 MAX_PAYLOAD 的数据段。
        """
        if not self._flows:
            return None

        for fid in sorted(self._flows.keys()):
            fs = self._flows[fid]
            if fs.remaining <= 0:
                continue
            seq = fs.next_seq
            payload = min(MAX_PAYLOAD, fs.remaining)
            if payload <= 0:
                continue
            fs.next_seq += payload
            return DataPacketSpec(
                flow_id=fid,
                seq_no=seq,
                payload_size=payload,
            )

        return None

    def on_packet_arrival(self, pkt: PacketView, ctx: HostContext) -> None:
        if pkt.is_ctrl:
            return
        flow_id = pkt.flow_id
        before = ctx.get_delivered_up_to(flow_id)

        if pkt.seq_no == before:
            ctx.deliver_packet(pkt.packet_id)
        else:
            self._ensure_rx_space_for(pkt, ctx)
            ctx.add_packet_to_buffer(pkt.packet_id)

        while True:
            current = ctx.get_delivered_up_to(flow_id)
            buf = ctx.get_received_packets()
            target: Optional[PacketView] = None
            for pv in buf:
                if pv.flow_id == flow_id and pv.seq_no == current:
                    target = pv
                    break
            if target is None:
                break
            ctx.deliver_packet(target.packet_id)


class MySwitchStrategy(SwitchStrategy):
    """
    Switch 策略：
    - on_link_ready：在端口队列中按 FIFO 选择队头包发送；
    - on_packet_arrival：在所有可用 next-hop 中选用端口当前使用量最小的一个，实现 per-packet ECMP。
    """

    def __init__(self) -> None:
        self._next_hops: Dict[int, List[LinkId]] = {}

    def on_sim_start(self, init: SwitchInitInfo) -> None:
        self._next_hops = dict(init.next_hops)

    def on_link_ready(self, output_port: LinkId, ctx: SwitchContext) -> Optional[Union[PacketId, ControlPacketSpec]]:
        ids = ctx.get_port_queue_packet_ids(output_port)
        if not ids:
            return None
        return ids[0]

    def on_packet_arrival(
        self,
        pkt: PacketView,
        input_port: LinkId,
        ctx: SwitchContext,
    ) -> Optional[LinkId]:
        # 在 hop 最短路候选集合中做 per-packet ECMP + 负载均衡，
        # 同时保证所选端口队列剩余容量足以容纳当前包，避免由框架丢包。
        candidates = self._next_hops.get(pkt.dst_node, [])
        if not candidates:
            return None

        alive: List[LinkId] = []
        for p in candidates:
            usage = ctx.get_port_usage(p)
            # 只保留“当前队列剩余空间 >= 本包大小”的端口
            if usage.capacity_bytes - usage.used_bytes >= pkt.size:
                alive.append(p)
        if not alive:
            return None

        # 选当前使用量最小的端口，实现简单负载均衡
        return min(alive, key=lambda p: ctx.get_port_usage(p).used_bytes)

    def on_timer(self, user_arg: object, ctx: SwitchContext) -> None:
        # 本策略不使用交换机定时器
        return None

