## 数据集：incast-112

### 1. 拓扑结构

- 规模：48 host + 64 switch（总 112 节点，switch >= 64）。
- 结构：24 edge + 16 aggregation + 24 core，core 额外环路增强长路径扰动。
- 参数：链路带宽统一为 1 Gbps，时延 8~60 us，host/switch buffer 均为 16 KB。

```mermaid
graph TD
  H["Hosts (48)"] --> E["Edge (24)"]
  E --> A["Aggregation (16)"]
  A --> C["Core (24)"]
  C --- C2["Core ring links"]
```

### 2. 流量设计（traffic.csv）

格式：

```text
FlowID,SrcNode,DstNode,SizeBytes,StartTimeUs,Priority,DeadlineUs
```

- 总流量约 68 MB（满足 50~200 MB）。
- 流数量：80 条（中高流数）。
- 时间分布：前 64 条流保留突发 incast 结构但做适度错相，后续高优先级流延后到约 1.58s 以内。

### 3. 重点考察

- 在统一低带宽下考察 incast 恢复能力与时序调节能力，避免“纯堆带宽”获得高分。
- 在多层交换结构中进行持续动态调整，而非一次性突发。
- 默认策略可完成全部流，但难以在该拥塞结构下拿到高分。
