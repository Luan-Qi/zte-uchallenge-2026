## 数据集：leafspine-176

### 1. 拓扑结构

- 规模：96 host + 80 switch（总 176 节点，host 接近上限）。
- 结构：32 leaf + 48 spine，标准 Clos 主体并带稀疏 spine 互联。
- 参数：带宽 18~35 Gbps，时延 2~12us，host/switch buffer 均为 16 KB。

```mermaid
graph TD
  H["Hosts (96)"] --> L["Leaf (32)"]
  L --> S["Spine (48)"]
  S --- S2["Sparse spine interconnect"]
```

### 2. 流量设计（traffic.csv）

格式：

```text
FlowID,SrcNode,DstNode,SizeBytes,StartTimeUs,Priority,DeadlineUs
```

- 总流量约 168 MB。
- 流数量：96 条（高流数）。
- 时间分布：前 80 条流做错相拉伸，后段流继续拉长到约 3.3s，形成持续 spine 竞争。

### 3. 重点考察

- 大规模并发与公平性压力。
- 高优先级小流与背景中流混跑下的实时调节能力。
- 默认策略可完成全部流，但在高并发下较难维持高得分。
