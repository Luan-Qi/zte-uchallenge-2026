"""
NetSched Cup — Switch 事件处理与策略调用

约束：
- 内核对选手 switch 策略的调用点必须出现在本文件中。
- 本文件包含与 switch 策略接口紧耦合的事件处理逻辑。
"""

from __future__ import annotations

from typing import Any

from event import Event, EventType
from packet import Packet, PacketType
from sim_api import ControlPacketSpec, LinkId, PacketId
from sim_state import DropReason


def _wrap_strategy_exception(callback_name: str, exc: Exception) -> None:
    raise AssertionError(f"选手策略异常（{callback_name}）: {type(exc).__name__}: {exc}") from exc


def handle_switch_arrival(sim: "Simulator", pkt: Packet, node_id: int, link_id: LinkId) -> None:
    sw_state = sim._switch_states.get(node_id)
    sw_strategy = sim._switch_strategies.get(node_id)
    ctx = sim._switch_ctx.get(node_id)
    if sw_state is None or sw_strategy is None or ctx is None:
        return

    sim._pkt_arrive_switch(pkt, node_id, link_id)
    sim._switch_curr_packet[node_id] = pkt
    # === 调用选手策略：switch.on_packet_arrival ===
    try:
        chosen_link = sw_strategy.on_packet_arrival(pkt, link_id, ctx)
    except AssertionError:
        raise
    except Exception as exc:
        _wrap_strategy_exception("switch.on_packet_arrival", exc)
    finally:
        sim._switch_curr_packet.pop(node_id, None)

    if chosen_link is None:
        # 交换机策略决定“不转发”：
        # - 对于 DATA 包：视为丢包，记录 PKT_DROP_AQM 并计入丢包统计；
        # - 对于 CTRL 包：仅视为“本节点消费/终止”，既不记录丢包日志、也不计入丢包统计。
        if pkt.is_ctrl:
            sim._pkt_purge(pkt.packet_id)
            return
        sim.logger.log_packet(sim.now, "PKT_DROP_AQM", pkt, node_id=node_id, link_id=link_id)
        sim._count_packet_drop(pkt, reason=DropReason.AQM_DATA, node_id=node_id)
        sim._pkt_purge(pkt.packet_id)
        return

    outbound = [lid for lid, _ in sim.topology.adjacency.get(node_id, [])]
    assert outbound, "【内部错误】当前交换机节点没有任何出端口"
    assert chosen_link in outbound, "on_packet_arrival 返回的输出端口不是当前节点的出端口"

    port = sw_state.get_port(chosen_link)
    packet_id = pkt.packet_id
    # 在策略选择出口端口时要求：该端口队列剩余容量必须能够容纳当前包，避免框架“偷偷丢包”
    remaining = port.capacity_bytes - port.total_bytes
    assert (
        remaining >= pkt.size
    ), "on_packet_arrival 选择的输出端口队列剩余空间不足以容纳该包，请调整选路或 AQM 策略"
    ok = port.enqueue(packet_id, pkt.size, sim.now)
    # 理论上在上述显式检查通过后 enqueue 一定成功，如失败则视为内部实现不一致
    assert ok, "【内部错误】端口队列容量检查与实际入队结果不一致"

    pkt._enqueue_time = sim.now
    sim._pkt_enqueue_switch(pkt, node_id, chosen_link)
    sim.logger.log_packet(sim.now, "PKT_ENQUEUE", pkt, node_id=node_id, link_id=chosen_link)

    link_state = sim._link_states.get((node_id, chosen_link))
    if link_state is not None and link_state.busy_until <= sim.now:
        sim._push_event(
            Event(
                time=sim.now,
                event_type=EventType.LINK_READY,
                node_id=node_id,
                link_id=chosen_link,
            )
        )


def handle_link_ready(sim: "Simulator", event: Event) -> None:
    node_id = event.node_id
    link_id = event.link_id
    link_state = sim._link_states.get((node_id, link_id))
    if link_state is None or link_state.busy_until > sim.now:
        return

    sw_strategy = sim._switch_strategies.get(node_id)
    ctx = sim._switch_ctx.get(node_id)
    if sw_strategy is None or ctx is None:
        return

    # === 调用选手策略：switch.on_link_ready ===
    try:
        choice = sw_strategy.on_link_ready(link_id, ctx)
    except AssertionError:
        raise
    except Exception as exc:
        _wrap_strategy_exception("switch.on_link_ready", exc)
    if choice is None:
        return

    did_send = False
    if isinstance(choice, ControlPacketSpec):
        assert isinstance(choice.dst_node, int), "ControlPacketSpec.dst_node 必须为整数"
        assert choice.dst_node in sim.topology.nodes, "ControlPacketSpec.dst_node 不是有效的节点 ID"
        send_control_packet_on_link(
            sim,
            node_id=node_id,
            link_id=link_id,
            dst_node=choice.dst_node,
            custom=choice.custom,
        )
        did_send = True
    else:
        assert isinstance(choice, int), "on_link_ready 返回值不合法：必须返回 PacketId(int) 或 ControlPacketSpec"
        sw_state = sim._switch_states.get(node_id)
        assert sw_state is not None, "【内部错误】找不到交换机状态"
        port = sw_state.get_port(link_id)
        in_queue = any(pid == choice for pid, _ in port.queue)
        assert in_queue, "on_link_ready 返回的 packet_id 不在该输出端口队列中"
        did_send = dequeue_and_send_packet(sim, node_id=node_id, link_id=link_id, packet_id=choice)

    if did_send and link_state is not None:
        sim._push_event(
            Event(
                time=link_state.busy_until,
                event_type=EventType.LINK_READY,
                node_id=node_id,
                link_id=link_id,
            )
        )


def handle_timer(sim: "Simulator", switch_id: int, user_arg: object) -> None:
    """custom_timer：switch 角色的策略回调入口。"""
    ctx = sim._switch_ctx.get(switch_id)
    sw_strategy = sim._switch_strategies.get(switch_id)
    if sw_strategy and ctx:
        # === 调用选手策略：switch.on_timer ===
        try:
            sw_strategy.on_timer(user_arg, ctx)
        except AssertionError:
            raise
        except Exception as exc:
            _wrap_strategy_exception("switch.on_timer", exc)


def schedule_link_ready(sim: "Simulator", node_id: int, link_id: LinkId) -> None:
    """请求一次 LINK_READY：仅当该端口为合法出端口且链路空闲时入队。"""
    outbound = [lid for lid, _ in sim.topology.adjacency.get(node_id, [])]
    if link_id not in outbound:
        return
    link_state = sim._link_states.get((node_id, link_id))
    if link_state is None or link_state.busy_until > sim.now:
        return
    sim._push_event(
        Event(
            time=sim.now,
            event_type=EventType.LINK_READY,
            node_id=node_id,
            link_id=link_id,
        )
    )


def drop_switch_queue_packet(sim: "Simulator", node_id: int, output_port: LinkId, packet_id: PacketId) -> None:
    """AQM 从输出端口队列丢包并清理包状态。"""
    sw = sim._switch_states.get(node_id)
    assert sw is not None, "【内部错误】找不到交换机状态"
    port = sw.get_port(output_port)
    removed = port.remove_by_id(packet_id)
    assert removed is not None, "drop_packet 指定的 packet_id 不在该输出端口队列中"
    pkt = sim._packets.packet_store.get(packet_id)
    if pkt:
        # AQM 从某个输出端口队列丢包：link_id 记录该输出端口（即输出链路 id）
        sim.logger.log_packet(sim.now, "PKT_DROP_AQM", pkt, node_id=node_id, link_id=output_port)
        sim._count_packet_drop(pkt, reason=DropReason.SWITCH_QUEUE_DROP, node_id=node_id)
        sim._pkt_purge(packet_id)


def send_control_packet_on_link(
    sim: "Simulator",
    *,
    node_id: int,
    link_id: LinkId,
    dst_node: int,
    custom: Any = None,
) -> None:
    """Switch 侧在指定链路上发送 CTRL 包（执行器）。"""
    pkt = Packet(
        src_node=node_id,
        dst_node=dst_node,
        flow_id=0,
        seq_no=0,
        payload_size=0,
        pkt_type=PacketType.CTRL,
        custom=custom if custom is not None else {},
        packet_id=sim._next_packet_id(),
        create_time=sim.now,
    )
    sim._packets.packet_store[pkt.packet_id] = pkt
    sim._pkt_register_sent_on_link(pkt, link_id)
    sim._count_packet_send(pkt)
    sim.logger.log_packet(sim.now, "CTRL_SEND", pkt, node_id=node_id, link_id=link_id)

    link_state = sim._link_states.get((node_id, link_id))
    assert link_state is not None, "【内部错误】指定 link_id 不存在"
    link = link_state.link
    tx_delay = link.transmission_delay_us(pkt.size)
    depart_time = max(sim.now, link_state.busy_until)
    link_state.busy_until = depart_time + tx_delay
    link_state.total_busy_time += tx_delay
    arrive_time = depart_time + tx_delay + link.latency_us
    peer = sim._peer_through_link(node_id, link_id)
    sim._push_event(
        Event(
            time=arrive_time,
            event_type=EventType.LINK_ARRIVE,
            node_id=peer,
            packet=pkt,
            link_id=link_id,
        )
    )


def dequeue_and_send_packet(
    sim: "Simulator",
    *,
    node_id: int,
    link_id: LinkId,
    packet_id: PacketId,
) -> bool:
    """Switch 侧从指定输出端口出队并发送一个 DATA/CTRL 包（执行器）。"""
    link_state = sim._link_states.get((node_id, link_id))
    if link_state is None or link_state.busy_until > sim.now:
        return False
    sw_state = sim._switch_states.get(node_id)
    if sw_state is None:
        return False
    port = sw_state.get_port(link_id)
    size = port.remove_by_id(packet_id)
    if size is None:
        assert False, "【内部错误】packet_id 不在当前端口队列中（入口校验应已拦截）"
    pkt = sim._packets.packet_store.get(packet_id)
    if pkt is None:
        assert False, "【内部错误】在发送包前在 packet_store 中找不到对应的 packet"
    sim._pkt_dequeue_on_link(pkt, link_id)
    link = link_state.link
    tx_delay = link.transmission_delay_us(pkt.size)
    depart_time = max(sim.now, link_state.busy_until)
    link_state.busy_until = depart_time + tx_delay
    link_state.total_busy_time += tx_delay
    arrive_time = depart_time + tx_delay + link.latency_us
    sim.logger.log_packet(sim.now, "PKT_FWD", pkt, node_id=node_id, link_id=link_id)
    peer = sim._peer_through_link(node_id, link_id)
    sim._push_event(
        Event(
            time=arrive_time,
            event_type=EventType.LINK_ARRIVE,
            node_id=peer,
            packet=pkt,
            link_id=link_id,
        )
    )
    return True

