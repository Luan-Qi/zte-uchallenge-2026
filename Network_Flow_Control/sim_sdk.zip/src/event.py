"""
NetSched Cup — 离散事件定义

仿真器事件队列中的事件类型与结构。
事件按 (time, tie_breaker) 排序，确保确定性。
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Optional

from packet import Packet


class EventType(Enum):
    LINK_ARRIVE = auto()    # 包到达下一跳节点
    LINK_READY = auto()     # 出口链路空闲：host 与交换机共用（host 仅一条出链路）
    FLOW_START = auto()     # 流开始事件
    CUSTOM_TIMER = auto()   # 策略自定义定时器回调


# 全局递增计数器，用于事件排序的平局打破
_tie_counter = 0


def _next_tie() -> int:
    global _tie_counter
    _tie_counter += 1
    return _tie_counter


@dataclass(order=True)
class Event:
    """
    仿真事件

    排序规则：先按 time 升序，再按 tie_breaker 升序（保证 FIFO 稳定性）。
    """
    time: float                                     # 事件触发时间（微秒）
    tie_breaker: int = field(default_factory=_next_tie)
    event_type: EventType = field(compare=False, default=EventType.FLOW_START)
    node_id: int = field(compare=False, default=-1)  # 事件关联的节点
    packet: Optional[Packet] = field(compare=False, default=None)
    link_id: int = field(compare=False, default=-1)  # 关联的链路
    flow_id: int = field(compare=False, default=-1)  # 关联的流
    extra: Any = field(compare=False, default=None)   # 附加数据

    def __repr__(self) -> str:
        return (
            f"Event(t={self.time:.2f}μs {self.event_type.name} "
            f"node={self.node_id} link={self.link_id})"
        )
