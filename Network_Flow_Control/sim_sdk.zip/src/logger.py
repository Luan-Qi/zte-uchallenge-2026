"""
NetSched Cup — 仿真日志记录器

记录事件时序日志（JSON Lines 格式），支持：
- 每个包的生命周期跟踪
- 队列深度时间序列
- 链路利用率统计
- 导出可视化所需的 JSON 数据
"""

import json
import os
from typing import List, Optional
from pathlib import Path

from packet import Packet


class SimLogger:
    """
    仿真日志器

    输出格式为 JSON Lines（每行一个 JSON 对象），
    便于后续分析工具逐行解析。
    """

    def __init__(self, output_path: Optional[str] = None, enabled: bool = True):
        self.enabled = enabled
        self._events: List[dict] = []
        self._output_path = output_path

    def log_event(self, time: float, event_type: str,
                  node_id: int = -1, **kwargs) -> None:
        """记录一个仿真事件"""
        if not self.enabled:
            return

        entry = {
            "time_us": round(time, 3),
            "event": event_type,
            "node": node_id,
        }
        entry.update(kwargs)
        self._events.append(entry)

    def log_packet(
        self,
        time: float,
        action: str,
        pkt: Packet,
        node_id: int = -1,
        link_id: int = -1,
        **kwargs,
    ) -> None:
        """记录包级事件"""
        if not self.enabled:
            return

        # - 本项目在加载 topology.json 时会为每条有向链路自动生成反向链路，反向链路 id = 原 id + 10000
        link_id = link_id % 10000 if link_id >= 10000 else link_id

        self.log_event(
            time=time,
            event_type=action,
            node_id=node_id,
            packet_id=pkt.packet_id,
            flow_id=pkt.flow_id,
            seq_no=pkt.seq_no,
            payload_size=pkt.payload_size,
            pkt_size=pkt.size,
            src=pkt.src_node,
            dst=pkt.dst_node,
            is_ctrl=pkt.is_ctrl,
            link_id=link_id,
            **kwargs,
        )

    def export(self, path: Optional[str] = None) -> None:
        """导出日志到文件"""
        out_path = path or self._output_path
        if not out_path:
            return

        p = Path(os.path.join(out_path,"sim_log.jsonl"))
        p.parent.mkdir(parents=True, exist_ok=True)

        with open(p, 'w', encoding='utf-8') as f:
            # 事件日志
            for entry in self._events:
                f.write(json.dumps(entry, ensure_ascii=False) + '\n')
