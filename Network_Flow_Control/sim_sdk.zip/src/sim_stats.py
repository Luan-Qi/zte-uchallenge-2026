"""
NetSched Cup — 仿真统计

事件次数统计与数据包发送/丢失/交付统计。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

from packet import Packet


@dataclass
class EventStats:
    """事件次数统计：event_type.name -> count"""

    counts: Dict[str, int] = field(default_factory=dict)

    def inc(self, event_type_name: str) -> None:
        self.counts[event_type_name] = self.counts.get(event_type_name, 0) + 1

    def to_dict(self) -> Dict[str, int]:
        return dict(self.counts)


@dataclass
class PacketStats:
    """包统计：发送/重传/丢失/成功交付（只统计 DATA 包的 delivered）。"""

    total_packets: int = 0
    total_data_packets: int = 0
    total_ctrl_packets: int = 0

    original_data_packets: int = 0
    retransmitted_data_packets: int = 0

    dropped_data_packets: int = 0
    dropped_ctrl_packets: int = 0

    delivered_data_packets: int = 0

    def count_send(self, pkt: Packet, *, is_retx: bool = False) -> None:
        self.total_packets += 1
        if pkt.is_ctrl:
            self.total_ctrl_packets += 1
            return
        self.total_data_packets += 1
        if is_retx:
            self.retransmitted_data_packets += 1
        else:
            self.original_data_packets += 1

    def count_drop(self, pkt: Packet) -> None:
        if pkt.is_ctrl:
            self.dropped_ctrl_packets += 1
        else:
            self.dropped_data_packets += 1

    def count_deliver(self, pkt: Packet) -> None:
        # 只统计成功交付的数据包
        if not pkt.is_ctrl:
            self.delivered_data_packets += 1

    def to_dict(self) -> Dict[str, int]:
        return {
            "total_packets": self.total_packets,
            "total_data_packets": self.total_data_packets,
            "total_ctrl_packets": self.total_ctrl_packets,
            "original_data_packets": self.original_data_packets,
            "retransmitted_data_packets": self.retransmitted_data_packets,
            "dropped_data_packets": self.dropped_data_packets,
            "dropped_ctrl_packets": self.dropped_ctrl_packets,
            "delivered_data_packets": self.delivered_data_packets,
        }

