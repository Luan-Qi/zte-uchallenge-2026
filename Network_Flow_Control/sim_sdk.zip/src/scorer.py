from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict
import math

if TYPE_CHECKING:
    from packet import Packet


@dataclass
class FlowResult:
    """单条流的仿真结果"""
    flow_id: int
    src_node: int
    dst_node: int
    size_bytes: int
    priority: int
    start_time_us: float
    end_time_us: float = 0.0
    deadline_us: float = float('inf')
    total_bytes_sent: int = 0
    total_bytes_retransmitted: int = 0
    # 已交付到上层的“连续前缀”字节数（左闭右开），即 delivered_up_to
    delivered_prefix_bytes: int = 0
    completed: bool = False

    _max_seen_seq: int = field(default=-1, init=False, repr=False)  # 该流已见最大 seq

    @property
    def fct_us(self) -> float:
        """实际流完成时间（微秒）"""
        if self.end_time_us > 0:
            return self.end_time_us - self.start_time_us
        return float('inf')

    @property
    def exceeded_deadline(self) -> bool:
        return self.fct_us > (self.deadline_us - self.start_time_us)


class Scorer:
    """
    评分器

    收集所有流的结果并计算最终得分。
    """

    def __init__(self):
        self.flow_results: Dict[int, FlowResult] = {}
        self.ideal_fcts: Dict[int, float] = {}  # flow_id -> T_ideal (μs)

    def register_flow(self, flow_id: int, src: int, dst: int,
                      size: int, priority: int,
                      start_time_us: float, deadline_us: float,
                      ideal_fct_us: float) -> None:
        """注册一条流及其理想 FCT"""
        self.flow_results[flow_id] = FlowResult(
            flow_id=flow_id,
            src_node=src,
            dst_node=dst,
            size_bytes=size,
            priority=priority,
            start_time_us=start_time_us,
            deadline_us=deadline_us,
        )
        self.ideal_fcts[flow_id] = ideal_fct_us

    def mark_flow_complete(self, flow_id: int, end_time_us: float,
                           bytes_sent: int, bytes_retransmitted: int) -> None:
        """标记流完成"""
        if flow_id in self.flow_results:
            fr = self.flow_results[flow_id]
            fr.end_time_us = end_time_us
            fr.total_bytes_sent = bytes_sent
            fr.total_bytes_retransmitted = bytes_retransmitted
            fr.completed = True

    # ─── 综合得分 ───

    def compute_final_score(self) -> Dict:
        """
        计算最终综合得分并返回详细报告。

        规则：
        - 先按加权 FCT 规则逐流计分，并将所有流得分求和，得到「原始总分」；
        - 再用「原始总分 / 所有流权重之和 × 100」做归一化，得到基准分；
        - 最终分 = 基准分 × (完成率)^2，其中完成率 = completed_flows / total_flows；
        - 未完成或超过 deadline 的流得分为 0，仅已完成且未超时的流参与计分；
        - 不再对公平性、重传率、乱序或完整性违规额外扣分。
        """
        # 计算原始总分（所有已完成且未超时的流的加权 FCT 之和）
        score = 0.0
        total_weight = 0.0
        for fid, fr in self.flow_results.items():
            # 统计所有流的权重之和（仅统计正权重），用于归一化分母
            if fr.priority > 0:
                total_weight += float(fr.priority)

            # 未完成的流不得分
            if not fr.completed:
                continue
            # 实际完成时长
            t_actual = fr.fct_us
            if not (t_actual > 0 and math.isfinite(t_actual)):
                continue
            # 超过 deadline 的流不得分
            if fr.exceeded_deadline:
                continue
            # 期望完成时长（ideal FCT）和权重
            t_ideal = self.ideal_fcts.get(fid, 0.0)
            if not (t_ideal > 0 and math.isfinite(t_ideal)):
                continue
            weight = float(fr.priority)
            if weight <= 0:
                continue
            ratio = min(t_ideal / t_actual, 1.0)
            score += weight * ratio

        total_flows = len(self.flow_results)
        completed_flows = sum(1 for fr in self.flow_results.values() if fr.completed)
        completion_ratio = (float(completed_flows) / float(total_flows)) if total_flows > 0 else 0.0

        # 归一化到 [0, 100]：数据集基准分上限为所有流权重之和
        if total_weight > 0:
            normalized = score / total_weight * 100.0
            penalized = normalized * (completion_ratio ** 2)
            final_score = max(0.0, min(100.0, penalized))
        else:
            final_score = 0.0

        # 统计
        deadline_violations = sum(
            1 for fr in self.flow_results.values() if fr.exceeded_deadline
        )

        return {
            "final_score":         round(final_score, 4),
            "total_flows":         total_flows,
            "completed_flows":     completed_flows,
            "deadline_violations": deadline_violations,
            "flow_details": {
                fid: {
                    "start_time_us":             round(fr.start_time_us, 2),
                    "end_time_us":               round(fr.end_time_us, 2),
                    "deadline_us":               round(fr.deadline_us, 2),
                    "fct_us":                    round(fr.fct_us, 2),
                    "ideal_fct_us":              round(self.ideal_fcts.get(fid, float("inf")), 2),
                    "completed":                 fr.completed,
                    "exceeded_deadline":         fr.exceeded_deadline,
                    "priority":                  fr.priority,
                    "size_bytes":                fr.size_bytes,
                    # 即使未完成，也展示已交付的前缀字节数（用于进度/定位问题）
                    "delivered_prefix_bytes":    int(fr.delivered_prefix_bytes),
                    "delivered_prefix_ratio":    (float(fr.delivered_prefix_bytes) / fr.size_bytes) if fr.size_bytes > 0 else 0.0,
                    "delivered_bytes":           (fr.size_bytes if fr.completed else 0),
                    "delivered_ratio":           (1.0 if fr.completed and fr.size_bytes > 0 else 0.0),
                }
                for fid, fr in self.flow_results.items()
            },
        }
