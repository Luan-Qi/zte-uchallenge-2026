"""
NetSched Cup — Host 接收缓冲/交付

包含 simulator.py 内与 host 接收缓冲相关的实现：
- add_packet_to_buffer
- deliver_packet
- drop_packet_in_buffer
- get_rx_buffer_remaining
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from sim_api import PacketId
from sim_state import DropReason

if TYPE_CHECKING:
    from simulator import Simulator  # pragma: no cover


def add_packet_to_buffer(sim: "Simulator", host_id: int, packet_id: PacketId) -> None:
    """将指定 packet_id 的 DATA 包加入接收缓冲（若容量允许）。"""
    meta = sim._rx_state.curr_rx_packet.get(host_id)
    if meta is None:
        return
    view, need, logged = meta
    if view.packet_id != packet_id:
        # 只允许将“当前包”加入缓冲，其它 packet_id 调用无效果
        return
    cap = sim._rx_state.rx_buffer_capacity.get(host_id, 0)
    if cap > 0:
        assert (
            sim._rx_state.rx_buffer_used[host_id] + need <= cap
        ), "接收缓冲空间不足，无法将当前包加入缓冲，请先丢弃部分缓冲中的包"
    # 接收成功：加入缓冲并记录到达
    if not logged:
        fr = sim.scorer.flow_results.get(view.flow_id)
        if fr is not None:
            rt = sim._packets.runtime.get(view.packet_id)
            _lid = rt.on_link_id if rt and rt.on_link_id is not None else -1
            sim.logger.log_packet(
                sim.now,
                "PKT_RECV",
                view,
                node_id=host_id,
                link_id=_lid,
            )
        meta = (view, need, True)
        sim._rx_state.curr_rx_packet[host_id] = meta
    sim._rx_state.rx_packets[host_id].append(view)
    sim._rx_state.rx_buffer_used[host_id] += need
    real = sim._packets.packet_store.get(view.packet_id)
    if real is not None:
        sim._pkt_mark_in_host_buffer(real, host_id)


def deliver_packet(sim: "Simulator", host_id: int, packet_id: PacketId) -> None:
    """
    将指定 packet_id 的 DATA 包交付给上层（推进 delivered_up_to）。

    注意：
    - 仅当该包的 seq_no 等于当前期望字节（前缀连续）时才会推进 delivered_up_to；
    - 成功交付后，框架会从接收缓冲中移除该包并结束其生命周期（packet_store / runtime 清理）；
    - 若该包既不是“当前包”，也不在接收缓冲中，则视为非法调用（断言失败）。
    """
    pkt = sim._packets.packet_store.get(packet_id)
    assert pkt is not None, "packet_id 不存在"

    fd = sim._flows.flow_demand.get(pkt.flow_id)
    assert fd is not None, "packet 所属 flow 不存在"
    assert fd.dst_node == host_id, "该包所属 flow 的 dst 不是当前 host"

    # 包确实在当前 host：要么是当前包，要么在接收缓冲
    meta = sim._rx_state.curr_rx_packet.get(host_id)
    is_current = meta is not None and meta[0].packet_id == packet_id
    in_buffer = any(pv.packet_id == packet_id for pv in sim._rx_state.rx_packets[host_id])
    assert is_current or in_buffer, "该包不在当前 host（既非当前到达包，也不在接收缓冲中）"

    # 前缀连续与越界校验
    current = sim._rx_state.delivered_up_to[host_id][pkt.flow_id]
    assert pkt.seq_no == current, "该包不是下一个期望字节（非前缀连续），无法交付"
    assert pkt.seq_no + pkt.payload_size <= fd.size_bytes, "该包超出流总大小范围"

    # 推进 delivered_up_to
    new_up = pkt.seq_no + pkt.payload_size
    sim._rx_state.delivered_up_to[host_id][pkt.flow_id] = new_up
    sim._delivered_flow_bytes += max(0, new_up - current)
    sim._count_packet_deliver(pkt)

    fr2 = sim.scorer.flow_results.get(pkt.flow_id)
    if fr2 is not None:
        fr2.delivered_prefix_bytes = max(fr2.delivered_prefix_bytes, int(new_up))
    if new_up >= fd.size_bytes:
        sim._mark_flow_complete(pkt.flow_id)

    # 交付成功：移出接收缓冲、同步 curr_rx，并 purge 包状态
    meta = sim._rx_state.curr_rx_packet.get(host_id)
    if meta is not None and meta[0].packet_id == packet_id:
        sim._rx_state.curr_rx_packet.pop(host_id, None)
    buf = sim._rx_state.rx_packets[host_id]
    dropped_sz = sum(pv.size for pv in buf if pv.packet_id == packet_id)
    sim._rx_state.rx_packets[host_id] = [pv for pv in buf if pv.packet_id != packet_id]
    if dropped_sz:
        sim._rx_state.rx_buffer_used[host_id] = max(
            0, sim._rx_state.rx_buffer_used[host_id] - dropped_sz
        )
    sim._pkt_purge(packet_id)


def drop_packet_in_buffer(sim: "Simulator", host_id: int, packet_id: PacketId) -> None:
    """丢弃接收缓冲中指定 packet_id 的包。"""
    assert any(
        pv.packet_id == packet_id for pv in sim._rx_state.rx_packets[host_id]
    ), "只能丢弃接收缓冲中的包"

    pkt = sim._packets.packet_store.get(packet_id)
    buf = sim._rx_state.rx_packets[host_id]
    for idx, pv in enumerate(buf):
        if pv.packet_id == packet_id:
            sim._rx_state.rx_packets[host_id] = buf[:idx] + buf[idx + 1 :]
            sim._rx_state.rx_buffer_used[host_id] = max(
                0, sim._rx_state.rx_buffer_used[host_id] - pv.size
            )
            break

    meta = sim._rx_state.curr_rx_packet.get(host_id)
    if meta is not None and getattr(meta[0], "packet_id", None) == packet_id:
        sim._rx_state.curr_rx_packet.pop(host_id, None)

    if pkt is not None:
        sim._count_packet_drop(pkt, reason=DropReason.HOST_BUFFER_DROP, node_id=host_id)
    sim._pkt_purge(packet_id)


def get_rx_buffer_remaining(sim: "Simulator", host_id: int) -> int:
    """返回当前 host 接收缓冲剩余空间（字节）。"""
    cap = sim._rx_state.rx_buffer_capacity.get(host_id, 0)
    if cap <= 0:
        # 无硬容量限制时，返回一个非负值（此处直接返回 0，表示“未限制”）
        return 0
    return max(0, cap - sim._rx_state.rx_buffer_used[host_id])

