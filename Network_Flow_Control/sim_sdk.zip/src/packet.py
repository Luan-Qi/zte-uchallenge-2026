"""
NetSched Cup — 精简数据包结构

目标：
- 仅保留仿真与路由所需的最小字段（src/dst、flow_id、seq_no、payload_size、pkt_type）。
- 提供一个完全由选手自定义的额外字段 `custom`，类型任意（可嵌套），仿真器不解析。

说明：
- MTU 固定为 **1500B**。
- DATA：链路等效字节数 = 固定头部 **64B** + `payload_size`，且总长不超过 MTU。
- CTRL：链路等效字节数 **固定 64B**；`payload_size` 恒为 0，语义信息与 `custom` 由策略自行约定。
"""

from enum import Enum, auto
from typing import Any


class PacketType(Enum):
    """数据包类型。"""
    DATA = auto()   # 数据包
    CTRL = auto()   # 控制/反馈包（ACK/SACK/ECN 等由策略在 custom 中自定义）


# ─────────────────── 模块级常量 ───────────────────

# 链路层 MTU（字节）
MTU = 1500
# DATA 固定头部长度（字节）
DATA_HEADER_BYTES = 64
# DATA 最大 payload（确保 DATA 总长不超过 MTU）
MAX_PAYLOAD = MTU - DATA_HEADER_BYTES
# CTRL：链路上固定占用字节数
CTRL_LINK_SIZE = 64

class Packet:
    """
    统一数据包（精简版）。

    除 custom 外所有字段对选手只读：改写会触发 AttributeError。
    custom 可重新赋值或修改内部字段。
    """

    def __init__(
        self,
        src_node: int,
        dst_node: int,
        flow_id: int,
        seq_no: int,
        payload_size: int,
        pkt_type: PacketType,
        custom: Any = None,
        packet_id: int = 0,
        create_time: float = 0.0,
        enqueue_time: float = 0.0,
    ):
        self._src_node = src_node
        self._dst_node = dst_node
        self._flow_id = flow_id
        self._seq_no = seq_no
        self._payload_size = payload_size
        self._pkt_type = pkt_type
        self.custom = custom if custom is not None else {}
        self._packet_id = packet_id
        self._create_time = create_time
        self._enqueue_time = enqueue_time

        if pkt_type == PacketType.CTRL:
            assert payload_size == 0, "【内部错误】CTRL 包 payload_size 必须为 0（链路长度见 size=CTRL_LINK_SIZE）"
        else:
            assert payload_size > 0, "【内部错误】DATA 包 payload_size 必须为正"
            assert (
                payload_size <= MAX_PAYLOAD
            ), f"【内部错误】DATA 包 payload_size 超过 {MAX_PAYLOAD}"
            assert (
                DATA_HEADER_BYTES + payload_size <= MTU
            ), f"【内部错误】DATA 包总长度超过 MTU={MTU}"

    # 只读属性：选手改写会报 AttributeError
    @property
    def src_node(self) -> int:
        return self._src_node

    @property
    def dst_node(self) -> int:
        return self._dst_node

    @property
    def flow_id(self) -> int:
        return self._flow_id

    @property
    def seq_no(self) -> int:
        return self._seq_no

    @property
    def payload_size(self) -> int:
        return self._payload_size

    @property
    def pkt_type(self) -> PacketType:
        return self._pkt_type

    @property
    def packet_id(self) -> int:
        return self._packet_id

    @property
    def create_time(self) -> float:
        return self._create_time

    @property
    def enqueue_time(self) -> float:
        return self._enqueue_time

    @property
    def size(self) -> int:
        """
        包在链路上的等效大小（用于带宽与队列建模）。

        - DATA：固定头部 DATA_HEADER_BYTES + payload_size（总长不超过 MTU）；
        - CTRL：固定 CTRL_LINK_SIZE（64B），与 custom 内容无关。
        """
        if self.pkt_type == PacketType.CTRL:
            return CTRL_LINK_SIZE
        return DATA_HEADER_BYTES + self._payload_size

    @property
    def is_ctrl(self) -> bool:
        """返回该包是否为控制包（CTRL）。"""
        return self.pkt_type == PacketType.CTRL

    def __repr__(self) -> str:
        return (
            f"Pkt({self.packet_id})"
            f" type={self.pkt_type.name}"
            f" flow={self.flow_id}"
            f" seq={self.seq_no}"
            f" size={self.size}B"
            f" {self.src_node}→{self.dst_node})"
        )

