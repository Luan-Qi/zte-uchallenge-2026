"""
NetSched Cup — 事件引擎

Simulator 的事件主循环与事件分发逻辑：
- 仍然使用 simulator 内的 _event_queue/now/max_time_us/_pop_event
- handlers 仍由 simulator 的 _handle_* 方法提供
- 事件次数统计使用 simulator._event_stats
- 进度输出使用 simulator._progress
"""

from __future__ import annotations

import time
from typing import Optional

from event import Event, EventType


def process_event(sim: "Simulator", event: Event) -> None:
    handlers = {
        EventType.FLOW_START: sim._handle_flow_start,
        EventType.LINK_READY: sim._handle_link_ready,
        EventType.LINK_ARRIVE: sim._handle_link_arrive,
        EventType.CUSTOM_TIMER: sim._handle_custom_timer,
    }
    name = event.event_type.name
    sim._event_stats.inc(name)

    h = handlers.get(event.event_type)
    if h:
        h(event)


def run_event_loop(sim: "Simulator", timeout_seconds: Optional[float] = None) -> dict:
    sim.logger.log_event(0, "SIM_START", total_flows=len(sim.flows))
    wall_start = time.time()
    timed_out = False
    termination_reason: str = "unknown"

    while sim._event_queue and sim.now < sim.max_time_us:
        if timeout_seconds is not None and (time.time() - wall_start) >= timeout_seconds:
            timed_out = True
            termination_reason = "wall_timeout"
            break

        event = sim._pop_event()
        if event is None:
            break

        sim.now = event.time
        if sim.now > sim.max_time_us:
            break

        process_event(sim, event)

        if sim._total_flow_bytes > 0:
            sim._progress.tick(
                delivered_flow_bytes=sim._delivered_flow_bytes,
                total_flow_bytes=sim._total_flow_bytes,
                sim_time_us=sim.now,
                wall_start_s=wall_start,
                now_wall_s=time.time(),
            )

    sim.logger.log_event(sim.now, "SIM_END")

    # 结束时换行，避免进度条占据当前行
    if sim._total_flow_bytes > 0:
        print()

    result = sim.scorer.compute_final_score()
    result["simulation_time_us"] = sim.now
    result["timeout_occurred"] = timed_out
    if timed_out:
        result["termination_reason"] = termination_reason
    else:
        # 区分退出原因：事件队列耗尽 或 仿真时间到达上限
        if not sim._event_queue:
            result["termination_reason"] = "event_queue_empty"
        elif sim.now >= sim.max_time_us:
            result["termination_reason"] = "sim_time_limit"
        else:
            result["termination_reason"] = "unknown"
    result["event_counts"] = sim._event_stats.to_dict()
    result["packet_stats"] = sim._packet_stats.to_dict()
    return result

