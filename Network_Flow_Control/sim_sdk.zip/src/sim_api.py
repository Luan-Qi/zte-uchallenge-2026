"""
NetSched Cup — 新架构：策略与仿真器交互 API

定义选手可实现的策略接口及仿真器提供的 Context API。
策略仅通过 Context 与仿真器交互，不直接访问内部状态。
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Protocol, Union

from packet import MAX_PAYLOAD as MAX_PAYLOAD

# PacketId 由仿真器分配，用于在队列与包视图中唯一标识一个包
PacketId = int

# LinkId：物理链路唯一标识；同一 id 在链路两端相同。从某节点经该 id 发往对端即一个「端口」。
LinkId = int


# ─────────────────── 发送端 API 类型 ───────────────────

class PacketView(Protocol):
    """
    包的视图接口；仿真器传入的实为 Packet。
    以下为只读属性（改写会报错）；仅 custom 可修改或重新赋值。
    """

    @property
    def packet_id(self) -> PacketId:
        ...

    @property
    def flow_id(self) -> int:
        ...

    @property
    def src_node(self) -> int:
        ...

    @property
    def dst_node(self) -> int:
        ...

    @property
    def seq_no(self) -> int:
        ...

    @property
    def payload_size(self) -> int:
        ...

    @property
    def is_ctrl(self) -> bool:
        """True 表示控制包，False 表示数据包。"""
        ...

    custom: Any  # 可修改内部字段或整体重新赋值

    @property
    def size(self) -> int:
        """
        包在链路上的等效大小（字节）。
        DATA：固定头部 + payload_size（总长不超过 MTU=1500，payload 上限 packet.MAX_PAYLOAD）；
        CTRL：固定 packet.CTRL_LINK_SIZE（64）。
        """
        ...


# ─────────────────── 交换机 API 类型 ───────────────────

@dataclass(frozen=True)
class PortUsage:
    """某输出端口当前缓冲使用情况；capacity_bytes 与该端口 FIFO 容量一致，等于 SwitchInitInfo.buffer_size_bytes。"""
    used_bytes: int
    capacity_bytes: int


@dataclass(frozen=True)
class DataPacketSpec:
    """Host 策略在 on_link_ready 中返回的 DATA 包发送描述。"""
    flow_id: int
    seq_no: int
    payload_size: int
    custom: Any = None


@dataclass(frozen=True)
class ControlPacketSpec:
    """
    发送一条 CTRL 包的描述。
    Host 在 on_link_ready、交换机在 on_link_ready 中均可返回本类型。
    仅需指定目的节点与 custom；Packet.src_node 由仿真器按当前发送节点填入。
    """
    dst_node: int
    custom: Any = None


# ─────────────────── 初始化快照（静态、一次性）───────────────────

@dataclass(frozen=True)
class LinkInfo:
    """本节点的一条直连链路：经 link_id 可达对端 peer；带宽与传播时延为链路属性。"""
    link_id: LinkId
    peer_node_id: int
    bandwidth_gbps: float
    latency_us: float


@dataclass(frozen=True)
class HostInitInfo:
    """
    Host 仿真开始前注入；赛题保证 host 恰有一条上行链路。

    buffer_size_bytes：接收缓冲总容量（字节），与 topology 中该 host 的 buffer_size_bytes
    及 HostContext 接收缓冲一致。
    simulation_time_us：仿真时钟上界（微秒），与 topology.json 的 global_config.simulation_time_us
    一致；到达该时刻事件循环停止（termination_reason 可能为 sim_time_limit）。
    """
    host_id: int
    link: LinkInfo
    buffer_size_bytes: int
    simulation_time_us: float


@dataclass(frozen=True)
class SwitchInitInfo:
    """
    交换机仿真开始前注入。

    next_hops：到各目的节点的最短路第一跳 link_id 候选（hop 最短路，与内核路由表一致）。
    buffer_size_bytes：每个输出端口 FIFO 的容量（字节），与 topology 中该交换机的 buffer_size_bytes
    一致；各端口队列相互独立、容量相同，均为此值（不按出端口数均分）。
    simulation_time_us：仿真时钟上界（微秒），与 HostInitInfo 中字段含义相同，全拓扑一致。
    """
    switch_id: int
    links: List[LinkInfo]
    next_hops: Dict[int, List[LinkId]]
    buffer_size_bytes: int
    simulation_time_us: float


class HostContext(Protocol):
    """仿真器提供给 Host 策略的运行期 API（随时间变化或有副作用）。"""

    def now_us(self) -> float:
        """当前仿真时间（微秒）。"""
        ...

    def schedule_timer(self, delay_us: float, arg: object) -> None:
        """
        注册定时器，在 now + delay_us（微秒）时触发 on_timer(arg, ctx)。

        delay_us 须为 int/float，且 >= 1.0（与仿真时间单位一致）。
        """
        ...

    def request_link_ready(self) -> None:
        """
        请求在唯一出链路空闲时再次触发 on_link_ready（与交换机侧同名 API 对应，Host 无需指定 link_id）。
        """
        ...

    def get_received_packets(self) -> List[PacketView]:
        """
        接收缓冲中所有未交付的包的只读视图列表（按接收顺序排序）。
        不按 flow 区分。
        """
        ...

    def get_delivered_up_to(self, flow_id: int) -> int:
        """该流已交付到上层的字节位置（左闭右开），即 [0, 返回值) 已连续交付。"""
        ...

    def add_packet_to_buffer(self, packet_id: PacketId) -> None:
        """
        将指定 packet_id 的 DATA 包加入接收缓冲。
        - 一般用于“当前刚到达”的包；
        - 若该包不在当前 host，则调用无效果；
        - 若缓冲容量不足，则触发断言失败。
        """
        ...

    def deliver_packet(self, packet_id: PacketId) -> None:
        """
        将指定 packet_id 的 DATA 包交付给上层。
        - 会校验：packet_id 存在；该包所属 flow 的 dst 为当前 host；
          该包确实位于当前 host（刚到达的“当前包”或在接收缓冲中）；
          且该包为前缀连续（seq_no 为下一个期望字节），并且不越过流总大小。
        - 成功交付后，该包从接收缓冲移除（若在缓冲中），并结束生命周期（packet_store 中不再存在）；
          此后不得再对该 packet_id 调用任何 Host 侧包操作 API。
        - 不会触发对缓冲中其他包的自动交付（是否继续交付其他包由选手自行循环调用本方法）。
        """
        ...

    def drop_packet_in_buffer(self, packet_id: PacketId) -> None:
        """
        丢弃接收缓冲中指定 packet_id 的包。
        若该包不在接收缓冲中则断言失败。
        丢弃后该包结束生命周期；若其与「当前到达包」为同一 packet_id，会同步清理当前包状态。
        """
        ...

    def get_rx_buffer_remaining(self) -> int:
        """当前 host 接收缓冲剩余空间（字节）。"""
        ...


class HostStrategy(ABC):
    """
    每个 host 一个统一的 Host 策略，实现发送与接收两侧逻辑。
    与交换机侧接口命名对齐：链路空闲时 on_link_ready；包到达时 on_packet_arrival。
    典型顺序：on_sim_start → on_flow_arrival → on_link_ready ↔ on_packet_arrival → on_timer → on_sim_end。
    """

    @abstractmethod
    def on_sim_start(self, init: HostInitInfo) -> None:
        """仿真开始前调用一次；静态信息仅从 init 获取。无需保存时可实现为空函数 `pass`。"""
        ...

    @abstractmethod
    def on_flow_arrival(
        self,
        flow_id: int,
        dst_node: int,
        size_bytes: int,
        priority: int,
        deadline_us: float,
        ctx: HostContext,
    ) -> None:
        """新流到达源 host 时调用。"""
        ...

    @abstractmethod
    def on_link_ready(self, ctx: HostContext) -> Optional[Union[DataPacketSpec, ControlPacketSpec]]:
        """
        唯一出链路空闲时调用（无 link_id 参数）。

        返回 DataPacketSpec / ControlPacketSpec：框架创建并发送一个包；
        返回 None：本次不发送。
        """
        ...

    @abstractmethod
    def on_packet_arrival(self, pkt: PacketView, ctx: HostContext) -> None:
        """
        任意包（DATA 或 CTRL）到达本 host 时调用（无 input_port 参数；仅一条入链路）。
        请用 pkt.is_ctrl 区分；CTRL 不进入交付/缓冲语义，处理完后由框架回收。
        """
        ...

    def on_timer(self, arg: object, ctx: HostContext) -> None:
        """自定义定时器回调，可选实现。"""
        pass

    def on_sim_end(self, ctx: HostContext) -> None:
        """仿真结束后调用一次，可用于本地统计/调试，不影响评分。"""
        pass


# ─────────────────── 交换机策略与 Context ───────────────────

class SwitchContext(Protocol):
    """仿真器提供给交换机策略的运行期 API（随时间变化或有副作用）。"""

    def now_us(self) -> float:
        ...

    def get_port_usage(self, output_port: LinkId) -> PortUsage:
        """该端口队列已用字节与容量；容量等于 on_sim_start 注入的 SwitchInitInfo.buffer_size_bytes。"""
        ...

    def get_port_queue_packet_ids(self, output_port: LinkId) -> List[PacketId]:
        """返回该输出端口队列中的 packet id 列表，FIFO 顺序。"""
        ...

    def get_packet_view(self, packet_id: PacketId) -> Optional[PacketView]:
        """通过 packet_id 获取只读视图；若该包不在当前节点则返回 None。"""
        ...

    def drop_packet(self, output_port: LinkId, packet_id: PacketId) -> None:
        """主动丢弃队列内指定包。"""
        ...

    def request_link_ready(self, output_port: LinkId) -> None:
        """请求在当前时间为该输出端口调度一次 LINK_READY。当本次 on_link_ready 不发送但希望该端口再次被调度时调用；仅当链路空闲时生效。"""
        ...

    def schedule_timer(self, delay_us: float, arg: object) -> None:
        """
        注册定时器，在 now + delay_us（微秒）时触发 on_timer(arg, ctx)。

        delay_us 须为 int/float，且 >= 1.0（与仿真时间单位一致）。
        """
        ...


class SwitchStrategy(ABC):
    """
    每交换机一个的调度策略。
    典型调用顺序：on_sim_start → on_link_ready 与 on_packet_arrival 在仿真中交错 → on_timer → on_sim_end。
    """

    @abstractmethod
    def on_sim_start(self, init: SwitchInitInfo) -> None:
        """仿真开始前调用一次；静态拓扑与最短路下一跳表仅从 init 获取。无需保存时可实现为空函数 `pass`。"""
        ...

    @abstractmethod
    def on_link_ready(self, output_port: LinkId, ctx: SwitchContext) -> Optional[Union[PacketId, ControlPacketSpec]]:
        """指定出向链路空闲时调用：返回 PacketId 从队列发出；或 ControlPacketSpec 发 CTRL；None 不发送。"""
        ...

    @abstractmethod
    def on_packet_arrival(self, pkt: PacketView, input_port: LinkId,
                          ctx: SwitchContext) -> Optional[LinkId]:
        """
        包到达时调用；input_port 为入向链路 ID。
        返回输出端口 ID（link_id）表示接受并入队该端口，返回 None 表示丢弃。
        """
        ...

    def on_timer(self, arg: object, ctx: SwitchContext) -> None:
        pass

    def on_sim_end(self, ctx: SwitchContext) -> None:
        """仿真结束后调用一次，可用于本地统计/调试，不影响评分。"""
        pass
