"""
NetSched Cup — Host 事件处理与策略调用

约束：
- 内核对选手 host 策略的调用点必须出现在本文件中。
- 这里承载与 host 策略接口相关的事件处理逻辑。
"""

from __future__ import annotations

from typing import Any

from event import Event, EventType
from packet import Packet, PacketType, MAX_PAYLOAD
from sim_api import DataPacketSpec, ControlPacketSpec, LinkId
from sim_state import DropReason


def _wrap_strategy_exception(callback_name: str, exc: Exception) -> None:
    raise AssertionError(f"选手策略异常（{callback_name}）: {type(exc).__name__}: {exc}") from exc


def schedule_host_link_ready(sim: "Simulator", host_id: int) -> None:
    """调度 LINK_READY：该 host 的唯一出链路忙闲决定就绪时间。"""
    adj = sim.topology.adjacency.get(host_id, [])
    if not adj:
        return
    link_id = adj[0][0]
    busy_until = sim._link_states[(host_id, link_id)].busy_until
    ready = max(sim.now, busy_until)
    sim._push_event(
        Event(
            time=ready,
            event_type=EventType.LINK_READY,
            node_id=host_id,
            link_id=link_id,
        )
    )


def handle_flow_start(sim: "Simulator", event: Event) -> None:
    fid = event.flow_id
    fd = sim._flows.flow_demand[fid]
    host_id = fd.src_node
    host_strategy = sim._host_strategies.get(host_id)
    ctx = sim._host_ctx.get(host_id)

    if host_strategy and ctx:
        try:
            host_strategy.on_flow_arrival(
                flow_id=fid,
                dst_node=fd.dst_node,
                size_bytes=fd.size_bytes,
                priority=fd.priority,
                deadline_us=fd.deadline_us,
                ctx=ctx,
            )
        except AssertionError:
            raise
        except Exception as exc:
            _wrap_strategy_exception("host.on_flow_arrival", exc)

    sim.logger.log_event(
        sim.now,
        "FLOW_START",
        node_id=fd.src_node,
        flow_id=fid,
        size=fd.size_bytes,
        priority=fd.priority,
    )
    schedule_host_link_ready(sim, host_id)


def handle_host_link_ready(sim: "Simulator", event: Event) -> None:
    host_id = event.node_id
    adj = sim.topology.adjacency.get(host_id, [])
    if not adj:
        return
    link_id = adj[0][0]
    if event.link_id >= 0 and event.link_id != link_id:
        return
    link_state = sim._link_states.get((host_id, link_id))
    if link_state is None or link_state.busy_until > sim.now:
        return

    host_strategy = sim._host_strategies.get(host_id)
    ctx = sim._host_ctx.get(host_id)
    if not host_strategy or not ctx:
        return

    try:
        spec = host_strategy.on_link_ready(ctx)
    except AssertionError:
        raise
    except Exception as exc:
        _wrap_strategy_exception("host.on_link_ready", exc)
    if spec is None:
        return

    if isinstance(spec, DataPacketSpec):
        out_links = sim.topology.get_outgoing_links(host_id)
        assert len(out_links) == 1, "【内部错误】host 必须且只能有一条出链路"
        _assert_data_send_spec_ok(sim, host_id, spec)

        _create_and_send_data_packet_impl(
            sim,
            host_id=host_id,
            flow_id=spec.flow_id,
            seq_no=spec.seq_no,
            payload_size=spec.payload_size,
            custom=spec.custom,
        )
        schedule_host_link_ready(sim, host_id)
    elif isinstance(spec, ControlPacketSpec):
        assert isinstance(spec.dst_node, int), "ControlPacketSpec.dst_node 必须为整数"
        out_links = sim.topology.get_outgoing_links(host_id)
        assert len(out_links) == 1, "【内部错误】host 必须且只能有一条出链路"
        assert spec.dst_node in sim.topology.nodes, "ControlPacketSpec.dst_node 不是有效的节点 ID"
        _send_control_packet_impl(
            sim,
            src_node=host_id,
            dst_node=spec.dst_node,
            custom=spec.custom,
        )
        schedule_host_link_ready(sim, host_id)
    else:
        raise AssertionError("on_link_ready 返回的 spec 类型不合法")


def handle_timer(sim: "Simulator", host_id: int, user_arg: object) -> None:
    """custom_timer：host 角色的策略回调入口。"""
    ctx = sim._host_ctx.get(host_id)
    host_strategy = sim._host_strategies.get(host_id)
    if host_strategy and ctx:
        try:
            host_strategy.on_timer(user_arg, ctx)
        except AssertionError:
            raise
        except Exception as exc:
            _wrap_strategy_exception("host.on_timer", exc)


def handle_host_arrival(sim: "Simulator", pkt: Packet, host_id: int, link_id: LinkId) -> None:
    if pkt.is_ctrl:
        host_strategy = sim._host_strategies.get(host_id)
        ctx = sim._host_ctx.get(host_id)
        if host_strategy and ctx:
            try:
                host_strategy.on_packet_arrival(pkt, ctx)
            except AssertionError:
                raise
            except Exception as exc:
                _wrap_strategy_exception("host.on_packet_arrival", exc)

        sim.logger.log_packet(sim.now, "CTRL_RECV", pkt, node_id=host_id, link_id=link_id)
        sim._pkt_purge(pkt.packet_id)
        schedule_host_link_ready(sim, host_id)
        return

    assert pkt.dst_node == host_id, "DATA 包到达 host 时 dst_node 与当前 host 不一致"
    fd = sim._flows.flow_demand.get(pkt.flow_id)
    if fd is None:
        sim._pkt_purge(pkt.packet_id)
        return

    host_strategy = sim._host_strategies.get(host_id)
    ctx = sim._host_ctx.get(host_id)
    if not host_strategy or not ctx:
        sim._pkt_purge(pkt.packet_id)
        return

    packet_id = pkt.packet_id

    # host 接收缓冲按完整包 size 计费（包含 DATA 固定头部）
    need = pkt.size
    sim._pkt_arrive_host_data(pkt, host_id, link_id)
    sim._rx_state.curr_rx_packet[host_id] = (pkt, need, False)

    try:
        host_strategy.on_packet_arrival(pkt, ctx)
    except AssertionError:
        raise
    except Exception as exc:
        _wrap_strategy_exception("host.on_packet_arrival", exc)

    rt = sim._packets.runtime.get(packet_id)
    terminal = rt.terminal if rt is not None else None
    in_buffer = any(pv.packet_id == packet_id for pv in sim._rx_state.rx_packets[host_id])

    still_in_store = sim._packets.packet_store.get(packet_id) is not None
    if (
        still_in_store
        and terminal is None
        and (not in_buffer)
    ):
        sim.logger.log_packet(
            sim.now,
            "PKT_DROP_UNHANDLED",
            pkt,
            node_id=host_id,
            link_id=link_id,
        )
        sim._count_packet_drop(pkt, reason=DropReason.HOST_UNHANDLED, node_id=host_id)
        sim._pkt_purge(packet_id)
        sim._rx_state.curr_rx_packet.pop(host_id, None)


def _assert_data_send_spec_ok(sim: "Simulator", host_id: int, spec: DataPacketSpec) -> None:
    assert isinstance(spec.flow_id, int), "flow_id 必须为整数"
    fd = sim._flows.flow_demand.get(spec.flow_id)
    assert fd is not None, "on_link_ready 返回的 flow_id 在当前数据集中不存在"
    assert fd.src_node == host_id, "on_link_ready 返回的 flow_id 不属于当前 host"
    assert sim.now >= fd.start_time_us, "不允许在流开始时间之前发送该流的数据包"

    assert isinstance(spec.seq_no, int) and spec.seq_no >= 0, "seq_no 必须为非负整数"
    assert isinstance(spec.payload_size, int) and spec.payload_size > 0, "payload_size 必须为正整数"
    assert spec.payload_size <= MAX_PAYLOAD, f"payload_size 超过最大载荷 MAX_PAYLOAD={MAX_PAYLOAD}"
    assert spec.seq_no + spec.payload_size <= fd.size_bytes, "DATA 包超出流大小范围"

    next_seq = sim._flows.flow_next_seq[spec.flow_id]
    sent_segments = sim._flows.flow_sent_segments[spec.flow_id]
    if spec.seq_no == next_seq:
        return
    if spec.seq_no < next_seq:
        assert spec.seq_no in sent_segments, "重传段不存在（该段从未发送过）"
        orig = sent_segments[spec.seq_no]
        assert spec.payload_size == orig, "重传段大小不一致"
        return
    assert False, "seq_no 不合法：不允许跳跃发送新数据段"


def _create_and_send_data_packet_impl(
    sim: "Simulator",
    *,
    host_id: int,
    flow_id: int,
    seq_no: int,
    payload_size: int,
    custom: Any = None,
) -> Packet:
    fd = sim._flows.flow_demand.get(flow_id)
    assert fd is not None, f"【内部错误】flow_id 不存在：{flow_id}"

    next_seq = sim._flows.flow_next_seq[flow_id]
    sent_segments = sim._flows.flow_sent_segments[flow_id]
    if seq_no == next_seq:
        sent_segments[seq_no] = payload_size
        sim._flows.flow_bytes_sent[flow_id] += payload_size
        sim._flows.flow_next_seq[flow_id] = next_seq + payload_size
        is_retx = False
    elif seq_no < next_seq:
        assert seq_no in sent_segments, "【内部错误】重传段不存在（入口校验应已拦截）"
        orig_size = sent_segments[seq_no]
        assert payload_size == orig_size, "【内部错误】重传段大小不一致（入口校验应已拦截）"
        sim._flows.flow_bytes_retx[flow_id] += payload_size
        is_retx = True
    else:
        assert False, "【内部错误】seq_no 跳跃发送（入口校验应已拦截）"

    pkt = Packet(
        src_node=host_id,
        dst_node=fd.dst_node,
        flow_id=flow_id,
        seq_no=seq_no,
        payload_size=payload_size,
        pkt_type=PacketType.DATA,
        custom=custom if custom is not None else {},
        packet_id=sim._next_packet_id(),
        create_time=sim.now,
    )
    sim._packets.packet_store[pkt.packet_id] = pkt
    adj = sim.topology.adjacency.get(host_id, [])
    assert adj, "【内部错误】host 没有出链路，无法发送 DATA 包"
    link_id = adj[0][0]
    sim._pkt_register_sent_on_link(pkt, link_id)

    sim._count_packet_send(pkt, is_retx=is_retx)
    sim.logger.log_packet(sim.now, "PKT_SEND", pkt, node_id=host_id, link_id=link_id)
    link_state = sim._link_states[(host_id, link_id)]
    link = link_state.link
    tx_delay = link.transmission_delay_us(pkt.size)
    depart_time = max(sim.now, link_state.busy_until)
    link_state.busy_until = depart_time + tx_delay
    link_state.total_busy_time += tx_delay
    arrive_time = depart_time + tx_delay + link.latency_us
    peer = sim._peer_through_link(host_id, link_id)
    sim._push_event(
        Event(
            time=arrive_time,
            event_type=EventType.LINK_ARRIVE,
            node_id=peer,
            packet=pkt,
            link_id=link_id,
        )
    )
    return pkt


def _send_control_packet_impl(sim: "Simulator", *, src_node: int, dst_node: int, custom: Any = None) -> None:
    pkt = Packet(
        src_node=src_node,
        dst_node=dst_node,
        flow_id=0,
        seq_no=0,
        payload_size=0,
        pkt_type=PacketType.CTRL,
        custom=custom if custom is not None else {},
        packet_id=sim._next_packet_id(),
        create_time=sim.now,
    )
    sim._packets.packet_store[pkt.packet_id] = pkt
    adj = sim.topology.adjacency.get(src_node, [])
    assert adj, "【内部错误】host 没有出链路，无法发送 CTRL 包"
    link_id = adj[0][0]
    sim._pkt_register_sent_on_link(pkt, link_id)
    sim._count_packet_send(pkt)
    sim.logger.log_packet(sim.now, "CTRL_SEND", pkt, node_id=src_node, link_id=link_id)
    link_state = sim._link_states[(src_node, link_id)]
    link = link_state.link
    tx_delay = link.transmission_delay_us(pkt.size)
    depart_time = max(sim.now, link_state.busy_until)
    link_state.busy_until = depart_time + tx_delay
    link_state.total_busy_time += tx_delay
    arrive_time = depart_time + tx_delay + link.latency_us
    peer = sim._peer_through_link(src_node, link_id)
    sim._push_event(
        Event(
            time=arrive_time,
            event_type=EventType.LINK_ARRIVE,
            node_id=peer,
            packet=pkt,
            link_id=link_id,
        )
    )
