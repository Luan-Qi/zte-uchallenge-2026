"""
NetSched Cup — 离散事件仿真器核心引擎（新架构）

- 每 host 一个 HostStrategy
- 交换机每条输出链路独立 FIFO，容量均为拓扑中该节点的 buffer_size_bytes（不按端口数均分）
- 策略仅通过 Context API 与仿真器交互
"""

import heapq
from typing import Any, Dict, List, Optional, Tuple

from packet import Packet
from event import Event, EventType
from config_loader import Topology, FlowDemand
from sim_api import (
    HostInitInfo,
    HostStrategy,
    LinkId,
    LinkInfo,
    PacketId,
    PacketView,
    SwitchInitInfo,
    SwitchStrategy,
)
from strategies.strategies_api import MyHostStrategy, MySwitchStrategy
from scorer import Scorer
from logger import SimLogger
from sim_stats import EventStats, PacketStats
from sim_progress import ProgressReporter
from routing import build_routing_table
from ideal_fct import compute_ideal_fct
import sim_host
import sim_switch
from sim_state import (
    FlowState,
    PacketPhase,
    PacketRuntimeState,
    PacketState,
    PacketTerminal,
    RxState,
)
from rx_buffer import (
    add_packet_to_buffer as _rx_add_packet_to_buffer,
    deliver_packet as _rx_deliver_packet,
    drop_packet_in_buffer as _rx_drop_packet_in_buffer,
    get_rx_buffer_remaining as _rx_get_rx_buffer_remaining,
)
from sim_context_impl import _HostContextImpl, _SwitchContextImpl
from event_engine import run_event_loop
from dataplane import LinkState, SwitchState


# ─────────────────── Context 实现（已抽离到 sim_context_impl.py）───────────────────


# ═══════════════════════════════════════════════
#  Simulator
# ═══════════════════════════════════════════════

class Simulator:
    def __init__(
        self,
        topology: Topology,
        flows: List[FlowDemand],
        wall_timeout_seconds: Optional[float] = None,
        log_enabled: bool = True,
        online_mode: bool = False,
        host_strategy_cls: type[HostStrategy] = MyHostStrategy,
        switch_strategy_cls: type[SwitchStrategy] = MySwitchStrategy,
    ):
        self.topology = topology
        self.flows = flows
        self.online_mode = online_mode
        self.now: float = 0.0
        self.max_time_us = topology.global_config.simulation_time_us
        self._wall_timeout_seconds: Optional[float] = wall_timeout_seconds
        self._event_queue: List[Event] = []

        # 策略类（可由外部注入自定义实现）
        self._host_strategy_cls: type[HostStrategy] = host_strategy_cls
        self._switch_strategy_cls: type[SwitchStrategy] = switch_strategy_cls

        # 每 host 一个统一的 HostStrategy
        self._host_strategies: Dict[int, HostStrategy] = {}
        self._switch_strategies: Dict[int, SwitchStrategy] = {}
        self._switch_states: Dict[int, SwitchState] = {}
        # 全双工：每条物理链路在每个端点上的发送占用独立 (sender_node_id, link_id)
        self._link_states: Dict[Tuple[int, LinkId], LinkState] = {}

        self.scorer = Scorer()
        self.logger = SimLogger(enabled=log_enabled)

        # 统一收敛 packet / flow / rx 的内部状态
        self._packets = PacketState()
        self._flows = FlowState()
        self._rx_state = RxState()

        self._host_ctx: Dict[int, _HostContextImpl] = {}
        self._switch_ctx: Dict[int, _SwitchContextImpl] = {}
        # 每个交换机当前在 on_packet_arrival 中处理的 Packet：node_id -> Packet
        self._switch_curr_packet: Dict[int, Packet] = {}
        # 路由表：node_id -> (dst_node -> [next_hop_link_ids])，按 hop 最短路计算
        self._routing_table: Dict[int, Dict[int, List[int]]] = {}

        # 进度统计：总流量与已完成流量（字节）
        self._total_flow_bytes: int = 0
        self._delivered_flow_bytes: int = 0
        self._progress = ProgressReporter()

        # 统计：事件次数、数据包计数
        self._event_stats = EventStats()
        self._packet_stats = PacketStats()

        self._initialize()

    def _next_packet_id(self) -> PacketId:
        self._packets.packet_id_counter += 1
        return self._packets.packet_id_counter

    def _peer_through_link(self, node_id: int, link_id: LinkId) -> int:
        for lid, peer in self.topology.adjacency.get(node_id, []):
            if lid == link_id:
                return peer
        assert False, f"link_id {link_id} 不是节点 {node_id} 的邻接链路"

    def _link_infos_for_node(self, node_id: int) -> List[LinkInfo]:
        out: List[LinkInfo] = []
        for lid, peer in self.topology.adjacency.get(node_id, []):
            link = self.topology.links.get(lid)
            if link is None:
                continue
            out.append(
                LinkInfo(
                    link_id=lid,
                    peer_node_id=peer,
                    bandwidth_gbps=link.bandwidth_gbps,
                    latency_us=link.latency_us,
                )
            )
        return out

    def _host_init_info(self, host_id: int) -> HostInitInfo:
        node = self.topology.nodes[host_id]
        infos = self._link_infos_for_node(host_id)
        assert len(infos) == 1, "【内部错误】host 必须且只能有一条邻接链路"
        return HostInitInfo(
            host_id=host_id,
            link=infos[0],
            buffer_size_bytes=node.buffer_size_bytes,
            simulation_time_us=self.topology.global_config.simulation_time_us,
        )

    def _switch_init_info(self, switch_id: int) -> SwitchInitInfo:
        node = self.topology.nodes[switch_id]
        nh = self._routing_table.get(switch_id) or {}
        return SwitchInitInfo(
            switch_id=switch_id,
            links=self._link_infos_for_node(switch_id),
            next_hops={k: list(v) for k, v in nh.items()},
            buffer_size_bytes=node.buffer_size_bytes,
            simulation_time_us=self.topology.global_config.simulation_time_us,
        )

    def _build_routing_table(self) -> None:
        """构建静态路由表（等价逻辑已抽离到 `src/routing.py`）。"""
        self._routing_table = build_routing_table(self.topology)

    def _initialize(self) -> None:
        for _lid, link in self.topology.links.items():
            self._link_states[(link.src, link.id)] = LinkState(link)
            self._link_states[(link.dst, link.id)] = LinkState(link)
        # 交换机：每个输出端口独立队列，容量均为该节点 topology.buffer_size_bytes（与 SwitchInitInfo 一致）
        for node in self.topology.get_switches():
            self._switch_states[node.id] = SwitchState(node, node.buffer_size_bytes)
            self._switch_strategies[node.id] = self._switch_strategy_cls()
            self._switch_ctx[node.id] = _SwitchContextImpl(self, node.id)
        for node in self.topology.get_hosts():
            self._host_strategies[node.id] = self._host_strategy_cls()
            self._host_ctx[node.id] = _HostContextImpl(self, node.id)
            # 接收缓冲容量：复用拓扑中该 host 的 buffer_size_bytes（未配置时使用默认值）
            self._rx_state.rx_buffer_capacity[node.id] = node.buffer_size_bytes

        # 构建静态路由表
        self._build_routing_table()

        # 初始化阶段：为每个 host 的唯一出链路、每个交换机出端口入队 LINK_READY（时间 0）
        t0 = 0.0
        for node in self.topology.get_hosts():
            adj = self.topology.adjacency.get(node.id, [])
            if adj:
                self._push_event(
                    Event(
                        time=t0,
                        event_type=EventType.LINK_READY,
                        node_id=node.id,
                        link_id=adj[0][0],
                    )
                )
        for node in self.topology.get_switches():
            for link_id, _ in self.topology.adjacency.get(node.id, []):
                self._push_event(Event(
                    time=t0,
                    event_type=EventType.LINK_READY,
                    node_id=node.id,
                    link_id=link_id,
                ))

        for fd in self.flows:
            self._flows.flow_demand[fd.flow_id] = fd
            self._flows.flow_completed[fd.flow_id] = False
            self._total_flow_bytes += fd.size_bytes
            ideal_fct = compute_ideal_fct(self.topology, fd)
            self.scorer.register_flow(
                flow_id=fd.flow_id,
                src=fd.src_node,
                dst=fd.dst_node,
                size=fd.size_bytes,
                priority=fd.priority,
                start_time_us=fd.start_time_us,
                deadline_us=fd.deadline_us,
                ideal_fct_us=ideal_fct,
            )
            self._push_event(Event(
                time=fd.start_time_us,
                event_type=EventType.FLOW_START,
                node_id=fd.src_node,
                flow_id=fd.flow_id,
            ))

    def _push_event(self, event: Event) -> None:
        heapq.heappush(self._event_queue, event)

    def _pop_event(self) -> Optional[Event]:
        if not self._event_queue:
            return None
        event = heapq.heappop(self._event_queue)
        return event

    def _count_packet_send(self, pkt: Packet, *, is_retx: bool = False) -> None:
        self._packet_stats.count_send(pkt, is_retx=is_retx)

    def _rt_ensure(self, packet_id: PacketId) -> PacketRuntimeState:
        if packet_id not in self._packets.runtime:
            self._packets.runtime[packet_id] = PacketRuntimeState()
        return self._packets.runtime[packet_id]

    def _pkt_purge(self, packet_id: PacketId) -> None:
        """从 packet_store 与 runtime 中移除（生命周期结束）。"""
        self._packets.packet_store.pop(packet_id, None)
        self._packets.runtime.pop(packet_id, None)

    def _pkt_register_sent_on_link(self, pkt: Packet, link_id: LinkId) -> None:
        r = self._rt_ensure(pkt.packet_id)
        r.phase = PacketPhase.ON_LINK
        r.on_link_id = link_id
        r.at_node_id = None
        r.queue_switch_id = None
        r.queue_output_port = None

    def _pkt_on_link_ingress(self, pkt: Packet, link_id: LinkId) -> None:
        r = self._rt_ensure(pkt.packet_id)
        r.on_link_id = link_id
        r.phase = PacketPhase.ON_LINK

    def _pkt_arrive_switch(self, pkt: Packet, switch_id: int, ingress_link: LinkId) -> None:
        r = self._rt_ensure(pkt.packet_id)
        r.phase = PacketPhase.AT_SWITCH
        r.at_node_id = switch_id
        r.on_link_id = ingress_link
        r.queue_switch_id = None
        r.queue_output_port = None

    def _pkt_enqueue_switch(self, pkt: Packet, switch_id: int, output_port: LinkId) -> None:
        r = self._rt_ensure(pkt.packet_id)
        r.phase = PacketPhase.IN_SWITCH_QUEUE
        r.at_node_id = switch_id
        r.queue_switch_id = switch_id
        r.queue_output_port = output_port

    def _pkt_dequeue_on_link(self, pkt: Packet, link_id: LinkId) -> None:
        r = self._rt_ensure(pkt.packet_id)
        r.phase = PacketPhase.ON_LINK
        r.on_link_id = link_id
        r.at_node_id = None
        r.queue_switch_id = None
        r.queue_output_port = None

    def _pkt_arrive_host_data(self, pkt: Packet, host_id: int, ingress_link: LinkId) -> None:
        r = self._rt_ensure(pkt.packet_id)
        r.phase = PacketPhase.AT_HOST
        r.at_node_id = host_id
        r.on_link_id = ingress_link

    def _pkt_mark_in_host_buffer(self, pkt: Packet, host_id: int) -> None:
        r = self._rt_ensure(pkt.packet_id)
        r.phase = PacketPhase.IN_HOST_BUFFER
        r.at_node_id = host_id

    def _count_packet_drop(self, pkt: Packet, *, reason: str, node_id: int) -> None:
        r = self._rt_ensure(pkt.packet_id)
        r.terminal = PacketTerminal.DROPPED
        r.drop_reason = reason
        r.drop_node_id = node_id
        self._packet_stats.count_drop(pkt)

    def _count_packet_deliver(self, pkt: Packet) -> None:
        """统计“成功交付”的数据包（DATA 推进 delivered_up_to）。"""
        r = self._rt_ensure(pkt.packet_id)
        r.terminal = PacketTerminal.DELIVERED
        self._packet_stats.count_deliver(pkt)

    @staticmethod
    def _wrap_strategy_exception(callback_name: str, exc: Exception) -> None:
        raise AssertionError(
            f"选手策略异常（{callback_name}）: {type(exc).__name__}: {exc}"
        ) from exc

    def run(self) -> dict:
        # 仿真正式开始前：注入静态快照（无 Context）
        for node in self.topology.get_hosts():
            strategy = self._host_strategies.get(node.id)
            if strategy is not None:
                try:
                    strategy.on_sim_start(self._host_init_info(node.id))
                except AssertionError:
                    raise
                except Exception as exc:
                    self._wrap_strategy_exception("host.on_sim_start", exc)

        for node in self.topology.get_switches():
            strategy = self._switch_strategies.get(node.id)
            if strategy is not None:
                try:
                    strategy.on_sim_start(self._switch_init_info(node.id))
                except AssertionError:
                    raise
                except Exception as exc:
                    self._wrap_strategy_exception("switch.on_sim_start", exc)

        result = run_event_loop(self, timeout_seconds=self._wall_timeout_seconds)

        # 线上测评模式：不调用 on_sim_end（避免额外输出/调试逻辑影响评测环境）
        if self.online_mode:
            return result

        # 仿真结束后，为每个 host/switch 调用一次策略的 on_sim_end（若实现），仅用于本地统计/调试
        for node in self.topology.get_hosts():
            strategy = self._host_strategies.get(node.id)
            ctx = self._host_ctx.get(node.id)
            try:
                strategy.on_sim_end(ctx)
            except AssertionError:
                raise
            except Exception as exc:
                self._wrap_strategy_exception("host.on_sim_end", exc)
  
        for node in self.topology.get_switches():
            strategy = self._switch_strategies.get(node.id)
            ctx = self._switch_ctx.get(node.id)
            try:
                strategy.on_sim_end(ctx)
            except AssertionError:
                raise
            except Exception as exc:
                self._wrap_strategy_exception("switch.on_sim_end", exc)
 

        return result

    def _create_and_send_data_packet(self,
                                     host_id: int,
                                     flow_id: int,
                                     seq_no: int,
                                     payload_size: int,
                                     custom: Any = None) -> PacketView:
        # 入口包装：将执行器创建逻辑委托给 `sim_host`，保持 Simulator 对外接口稳定。
        return sim_host._create_and_send_data_packet_impl(
            self,
            host_id=host_id,
            flow_id=flow_id,
            seq_no=seq_no,
            payload_size=payload_size,
            custom=custom,
        )

    def _get_received_packets(self, host_id: int) -> List[PacketView]:
        """返回该 host 接收缓冲中所有未交付的包的视图列表（副本，顺序与缓冲一致）。"""
        return list(self._rx_state.rx_packets[host_id])

    def _get_delivered_up_to(self, host_id: int, flow_id: int) -> int:
        """返回该 host 上该流已交付到上层的字节位置（左闭右开）。"""
        return self._rx_state.delivered_up_to[host_id][flow_id]

    def _add_packet_to_buffer(self, host_id: int, packet_id: PacketId) -> None:
        """将指定 packet_id 的 DATA 包加入接收缓冲（若容量允许）。"""
        _rx_add_packet_to_buffer(self, host_id, packet_id)

    def _deliver_packet(self, host_id: int, packet_id: PacketId) -> None:
        """根据 packet_id 将当前包或缓冲中的包交付给上层。"""
        _rx_deliver_packet(self, host_id, packet_id)

    def _drop_packet_in_buffer(self, host_id: int, packet_id: PacketId) -> None:
        """丢弃接收缓冲中指定 packet_id 的包。"""
        _rx_drop_packet_in_buffer(self, host_id, packet_id)

    def _get_rx_buffer_remaining(self, host_id: int) -> int:
        """返回当前 host 接收缓冲剩余空间（字节）。"""
        return _rx_get_rx_buffer_remaining(self, host_id)

    def _mark_flow_complete(self, flow_id: int) -> None:
        if self._flows.flow_completed.get(flow_id, False):
            return
        self._flows.flow_completed[flow_id] = True
        fd = self._flows.flow_demand[flow_id]
        self.scorer.mark_flow_complete(
            flow_id=flow_id,
            end_time_us=self.now,
            bytes_sent=self._flows.flow_bytes_sent.get(flow_id, 0),
            bytes_retransmitted=self._flows.flow_bytes_retx.get(flow_id, 0),
        )
        self.logger.log_event(
            self.now, "FLOW_COMPLETE",
            node_id=fd.dst_node,
            flow_id=flow_id,
            fct_us=round(self.now - fd.start_time_us, 2),
        )

    def _send_control_packet(self, src_node: int, dst_node: int, custom: Any = None) -> None:
        """创建并发送一个 CTRL 包，按 src_node/dst_node 定位端点。"""
        sim_host._send_control_packet_impl(self, src_node=src_node, dst_node=dst_node, custom=custom)

    def _send_control_packet_on_link(
        self, node_id: int, link_id: LinkId, dst_node: int, custom: Any = None
    ) -> None:
        """从 node_id 经指定 link_id 发出一个 CTRL 包（用于交换机在 on_link_ready 时主动发包）。"""
        sim_switch.send_control_packet_on_link(
            self,
            node_id=node_id,
            link_id=link_id,
            dst_node=dst_node,
            custom=custom,
        )

    def _drop_switch_queue_packet(self, node_id: int, output_port: LinkId, packet_id: PacketId) -> None:
        sim_switch.drop_switch_queue_packet(self, node_id=node_id, output_port=output_port, packet_id=packet_id)

    def _handle_flow_start(self, event: Event) -> None:
        sim_host.handle_flow_start(self, event)

    def _schedule_host_link_ready(self, host_id: int) -> None:
        sim_host.schedule_host_link_ready(self, host_id)

    def _handle_link_arrive(self, event: Event) -> None:
        pkt = event.packet
        node_id = event.node_id
        link_id = event.link_id
        if pkt is None:
            return

        # 维护入链路 id（日志 PKT_RECV 等）
        self._pkt_on_link_ingress(pkt, link_id)

        node = self.topology.nodes[node_id]
        if node.is_host:
            sim_host.handle_host_arrival(self, pkt, host_id=node_id, link_id=link_id)
        else:
            sim_switch.handle_switch_arrival(self, pkt, node_id=node_id, link_id=link_id)

    def _handle_host_arrival(self, pkt: Packet, host_id: int, link_id: LinkId) -> None:
        sim_host.handle_host_arrival(self, pkt, host_id=host_id, link_id=link_id)

    def _handle_switch_arrival(self, pkt: Packet, node_id: int, link_id: LinkId) -> None:
        sim_switch.handle_switch_arrival(self, pkt, node_id=node_id, link_id=link_id)

    def _schedule_link_ready(self, node_id: int, link_id: LinkId) -> None:
        sim_switch.schedule_link_ready(self, node_id=node_id, link_id=link_id)

    def _handle_link_ready(self, event: Event) -> None:
        """出口链路空闲：host 与交换机分别进入各自的 on_link_ready 实现。"""
        node = self.topology.nodes.get(event.node_id)
        if node is None:
            return
        if node.is_host:
            sim_host.handle_host_link_ready(self, event)
        else:
            sim_switch.handle_link_ready(self, event)

    def _handle_custom_timer(self, event: Event) -> None:
        extra = event.extra
        if not isinstance(extra, (tuple, list)) or len(extra) < 3:
            return
        role, key, user_arg = extra[0], extra[1], extra[2]
        if role == "host":
            sim_host.handle_timer(self, host_id=key, user_arg=user_arg)
        elif role == "switch":
            sim_switch.handle_timer(self, switch_id=key, user_arg=user_arg)

    # ──────────────── 通用校验 helper（供 context_impl 调用） ────────────────

    def _validate_host_packet_id(self, host_id: int, packet_id: PacketId, require_data: bool = True) -> Packet:
        """校验 host 侧使用的 packet_id 合法性，返回对应 Packet。

        - packet_id 必须为正整数；
        - 对应包必须存在；
        - 若 require_data=True，则必须为 DATA 包；
        - 包当前所在节点必须为 host_id。
        """
        assert isinstance(packet_id, int) and packet_id > 0, "packet_id 必须为正整数"
        pkt = self._packets.packet_store.get(packet_id)
        assert pkt is not None, "packet_id 对应的包不存在"
        if require_data:
            assert not pkt.is_ctrl, "packet_id 对应的包不是数据包"
        r = self._packets.runtime.get(packet_id)
        assert r is not None, "【内部错误】packet 无运行时记录"
        assert r.terminal is None, "该数据包已结束生命周期，不允许再操作"
        assert r.at_node_id == host_id, "packet_id 对应的包不在当前 host 节点"
        assert r.phase in (
            PacketPhase.AT_HOST,
            PacketPhase.IN_HOST_BUFFER,
        ), "packet_id 对应的包不在当前 host 可处理状态"
        return pkt

    def set_host_strategy(self, host_id: int, strategy: HostStrategy) -> None:
        self._host_strategies[host_id] = strategy

    def set_switch_strategy(self, node_id: int, strategy: SwitchStrategy) -> None:
        self._switch_strategies[node_id] = strategy
