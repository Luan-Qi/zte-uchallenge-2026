"""
NetSched Cup — Context 实现

提供 HostContext / SwitchContext 的内部实现（仅仿真器内部使用）。
"""

from __future__ import annotations

from typing import List, Optional, TYPE_CHECKING

from event import Event, EventType
from sim_api import LinkId, PacketId, PacketView, PortUsage

if TYPE_CHECKING:  # pragma: no cover
    from simulator import Simulator


class _HostContextImpl:
    """内部 HostContext 实现，统一提供发送/接收相关 API。"""

    def __init__(self, sim: "Simulator", host_id: int):
        self._sim = sim
        self._host_id = host_id

    def now_us(self) -> float:
        return self._sim.now

    def schedule_timer(self, delay_us: float, arg: object) -> None:
        assert isinstance(delay_us, (int, float)), "schedule_timer 的 delay_us 必须为数字"
        assert delay_us >= 1.0, "schedule_timer 的 delay_us 至少为 1.0"
        user_arg = arg
        self._sim._push_event(
            Event(
                time=self._sim.now + delay_us,
                event_type=EventType.CUSTOM_TIMER,
                node_id=self._host_id,
                extra=("host", self._host_id, user_arg),
            )
        )

    def request_link_ready(self) -> None:
        self._sim._schedule_host_link_ready(self._host_id)

    def get_received_packets(self) -> List[PacketView]:
        return self._sim._get_received_packets(self._host_id)

    def get_delivered_up_to(self, flow_id: int) -> int:
        assert isinstance(flow_id, int) and flow_id > 0, "flow_id 必须为正整数"
        fd = self._sim._flows.flow_demand.get(flow_id)
        assert fd is not None, "flow_id 在当前数据集中不存在"
        assert self._sim.now >= fd.start_time_us, "该流尚未开始，不能查询 delivered_up_to"
        assert fd.dst_node == self._host_id, "该流的目的 host 不是当前 host，不能查询 delivered_up_to"

        return self._sim._get_delivered_up_to(self._host_id, flow_id)

    def add_packet_to_buffer(self, packet_id: PacketId) -> None:
        pkt = self._sim._validate_host_packet_id(self._host_id, packet_id, require_data=True)

        # 重复入缓冲通常意味着策略状态管理出错，应明确报错而不是静默忽略
        buf = self._sim._rx_state.rx_packets[self._host_id]
        assert not any(
            pv.packet_id == pkt.packet_id for pv in buf
        ), "该数据包已在接收缓冲中，无需重复加入"

        # 只允许对“当前到达的包”调用 add_packet_to_buffer
        meta = self._sim._rx_state.curr_rx_packet.get(self._host_id)
        assert (
            meta is not None and meta[0].packet_id == pkt.packet_id
        ), "add_packet_to_buffer 只能用于当前刚到达的 DATA 包"

        # 根据当前包还需要占用的字节数 need 与缓冲剩余空间做校验
        _, need, _ = meta
        remaining = self._sim._get_rx_buffer_remaining(self._host_id)
        capacity = self._sim._rx_state.rx_buffer_capacity.get(self._host_id, 0)
        if capacity > 0:
            assert (
                remaining >= need
            ), "接收缓冲空间不足，无法将当前包加入缓冲，请先丢弃部分缓冲中的包"

        self._sim._add_packet_to_buffer(self._host_id, pkt.packet_id)

    def deliver_packet(self, packet_id: PacketId) -> None:
        # 校验 packet 存在、为 DATA 包、且属于当前 host
        self._sim._validate_host_packet_id(self._host_id, packet_id, require_data=True)
        self._sim._deliver_packet(self._host_id, packet_id)

    def drop_packet_in_buffer(self, packet_id: PacketId) -> None:
        # 仅作用于缓冲中的 DATA 包
        self._sim._validate_host_packet_id(self._host_id, packet_id, require_data=True)
        self._sim._drop_packet_in_buffer(self._host_id, packet_id)

    def get_rx_buffer_remaining(self) -> int:
        return self._sim._get_rx_buffer_remaining(self._host_id)

    def get_flow_size(self, flow_id: int) -> int:
        assert isinstance(flow_id, int) and flow_id > 0, "flow_id 必须为正整数"
        fd = self._sim._flows.flow_demand.get(flow_id)
        assert fd is not None, "flow_id 在当前数据集中不存在"
        return fd.size_bytes


class _SwitchContextImpl:
    def __init__(self, sim: "Simulator", node_id: int):
        self._sim = sim
        self._node_id = node_id

    def _incident_link_ids(self) -> frozenset:
        return frozenset(
            lid for lid, _ in self._sim.topology.adjacency.get(self._node_id, [])
        )

    def now_us(self) -> float:
        return self._sim.now

    def get_port_usage(self, output_port: LinkId) -> PortUsage:
        assert output_port in self._incident_link_ids(), "output_port 不是当前节点的邻接链路"
        sw = self._sim._switch_states.get(self._node_id)
        if sw is None:
            return PortUsage(0, 0)
        port = sw.get_port(output_port)
        return PortUsage(used_bytes=port.total_bytes, capacity_bytes=port.capacity_bytes)

    def get_port_queue_packet_ids(self, output_port: LinkId) -> List[PacketId]:
        """返回该输出端口队列中的 packet id 列表，FIFO 顺序。"""
        assert output_port in self._incident_link_ids(), "output_port 不是当前节点的邻接链路"
        sw = self._sim._switch_states.get(self._node_id)
        if sw is None:
            return []
        port = sw.get_port(output_port)
        return [pid for pid, _ in port.queue]

    def get_packet_view(self, packet_id: PacketId) -> Optional[PacketView]:
        """通过 packet_id 获取包视图（实为 Packet）；若该包不在当前节点则返回 None。"""
        assert isinstance(packet_id, int) and packet_id > 0, "packet_id 必须为正整数"
        curr = self._sim._switch_curr_packet.get(self._node_id)
        if curr is not None and curr.packet_id == packet_id:
            return curr
        r = self._sim._packets.runtime.get(packet_id)
        if r is None or r.terminal is not None:
            return None
        if r.location_node_for_switch_view() != self._node_id:
            return None
        pkt = self._sim._packets.packet_store.get(packet_id)
        return pkt

    def drop_packet(self, output_port: LinkId, packet_id: PacketId) -> None:
        assert output_port in self._incident_link_ids(), "output_port 不是当前节点的邻接链路"
        assert isinstance(packet_id, int) and packet_id > 0, "packet_id 必须为正整数"
        self._sim._drop_switch_queue_packet(self._node_id, output_port, packet_id)

    def request_link_ready(self, output_port: LinkId) -> None:
        assert output_port in self._incident_link_ids(), "output_port 不是当前节点的邻接链路"
        self._sim._schedule_link_ready(self._node_id, output_port)

    def schedule_timer(self, delay_us: float, arg: object) -> None:
        assert isinstance(delay_us, (int, float)), "schedule_timer 的 delay_us 必须为数字"
        assert delay_us >= 1.0, "schedule_timer 的 delay_us 至少为 1.0"
        user_arg = arg
        self._sim._push_event(
            Event(
                time=self._sim.now + delay_us,
                event_type=EventType.CUSTOM_TIMER,
                node_id=self._node_id,
                extra=("switch", self._node_id, user_arg),
            )
        )
