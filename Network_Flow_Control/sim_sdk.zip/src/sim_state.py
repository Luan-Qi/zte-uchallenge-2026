"""
NetSched Cup — Simulator 内部状态对象

为每个 `packet_id` 维护一条运行时记录 `PacketRuntimeState`，集中承载包阶段、队列/链路附加信息，以及终端态的丢弃原因与位置。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, Optional, Tuple, List
from collections import defaultdict

from packet import Packet
from sim_api import PacketId, PacketView, LinkId
from config_loader import FlowDemand


class PacketPhase(Enum):
    """非终端：包在网络/节点内的位置（简化状态机）。"""

    CREATED = auto()
    ON_LINK = auto()
    AT_SWITCH = auto()  # 到达交换机，策略 on_packet_arrival 处理中或刚决策完
    IN_SWITCH_QUEUE = auto()
    AT_HOST = auto()  # 作为当前到达 DATA，策略 on_packet 尚未结束
    IN_HOST_BUFFER = auto()


class PacketTerminal(Enum):
    """终端态：包不再参与转发/选手操作（对应 packet_store 中将被移除）。"""

    DELIVERED = auto()
    DROPPED = auto()
    CONSUMED = auto()  # 例如 CTRL 在交换机被策略终止且无丢包统计


class DropReason:
    """丢包原因常量（写入日志/运行时，便于分析）。"""

    AQM_DATA = "AQM_DATA"
    HOST_UNHANDLED = "HOST_UNHANDLED"
    HOST_BUFFER_DROP = "HOST_BUFFER_DROP"
    SWITCH_QUEUE_DROP = "SWITCH_QUEUE_DROP"


@dataclass
class PacketRuntimeState:
    """
    单包运行时状态。

    - phase：非终端位置；terminal 非空时 phase 可视为未使用。
    - on_link_id：处于链路上或刚经该 ingress link 到达节点时记录（与日志 PKT_RECV 等一致）。
    - at_node_id：包“附着”的节点（host 侧 AT_HOST/IN_HOST_BUFFER；交换机侧 AT_SWITCH/IN_SWITCH_QUEUE）。
    - queue_*：仅在 IN_SWITCH_QUEUE 时有意义。
    - drop_*：仅在 terminal==DROPPED 时有意义。
    """

    phase: PacketPhase = PacketPhase.CREATED
    terminal: Optional[PacketTerminal] = None

    on_link_id: Optional[LinkId] = None
    at_node_id: Optional[int] = None

    queue_switch_id: Optional[int] = None
    queue_output_port: Optional[LinkId] = None

    drop_reason: Optional[str] = None
    drop_node_id: Optional[int] = None

    def location_node_for_switch_view(self) -> Optional[int]:
        """供交换机 get_packet_view：包是否算“在本交换机节点上”。"""
        if self.terminal is not None:
            return None
        if self.phase in (PacketPhase.AT_SWITCH, PacketPhase.IN_SWITCH_QUEUE):
            return self.at_node_id
        return None


@dataclass
class PacketState:
    packet_store: Dict[PacketId, Packet] = field(default_factory=dict)
    packet_id_counter: int = 0
    runtime: Dict[PacketId, PacketRuntimeState] = field(default_factory=dict)


@dataclass
class FlowState:
    flow_demand: Dict[int, FlowDemand] = field(default_factory=dict)
    flow_completed: Dict[int, bool] = field(default_factory=dict)

    # bytes statistics
    flow_bytes_sent: Dict[int, int] = field(default_factory=lambda: defaultdict(int))
    flow_bytes_retx: Dict[int, int] = field(default_factory=lambda: defaultdict(int))

    # sending model state
    flow_next_seq: Dict[int, int] = field(default_factory=lambda: defaultdict(int))
    flow_sent_segments: Dict[int, Dict[int, int]] = field(default_factory=lambda: defaultdict(dict))


@dataclass
class RxState:
    # host_id -> [PacketView, ...] (arrival order)
    rx_packets: Dict[int, List[PacketView]] = field(default_factory=lambda: defaultdict(list))

    # host_id -> (PacketView, need_bytes, logged_flag)
    curr_rx_packet: Dict[int, Tuple[PacketView, int, bool]] = field(default_factory=dict)

    # host_id -> flow_id -> delivered_up_to bytes
    delivered_up_to: Dict[int, Dict[int, int]] = field(
        default_factory=lambda: defaultdict(lambda: defaultdict(int))
    )

    # host_id -> bytes
    rx_buffer_capacity: Dict[int, int] = field(default_factory=dict)
    rx_buffer_used: Dict[int, int] = field(default_factory=lambda: defaultdict(int))
