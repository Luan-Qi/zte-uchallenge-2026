"""
NetSched Cup — 数据面模型

定义数据面内部状态：
- LinkState：链路忙闲与累计忙时统计
- PortState：交换机输出端口 FIFO 队列
- SwitchState：交换机的多个 PortState 聚合
"""

from __future__ import annotations

from collections import deque
from typing import Deque, Dict, Optional, Tuple

from config_loader import Link, Node

from sim_api import PacketId


class LinkState:
    def __init__(self, link: Link):
        self.link = link
        self.busy_until: float = 0.0
        self.total_busy_time: float = 0.0


class PortState:
    """单个输出端口：FIFO 队列只存 (packet_id, size)。"""

    def __init__(self, capacity_bytes: int):
        self.capacity_bytes = capacity_bytes
        self.queue: Deque[Tuple[PacketId, int]] = deque()
        self.total_bytes: int = 0

    def enqueue(self, packet_id: PacketId, size: int, current_time: float) -> bool:
        if self.total_bytes + size > self.capacity_bytes:
            return False
        self.queue.append((packet_id, size))
        self.total_bytes += size
        return True

    def has_packets(self) -> bool:
        return bool(self.queue)

    def remove_by_id(self, packet_id: PacketId) -> Optional[int]:
        """从队列移除该 packet_id，返回其 size；不存在返回 None。"""
        if self.queue and self.queue[0][0] == packet_id:
            _, size = self.queue.popleft()
            self.total_bytes -= size
            return size

        for idx, (pid, size) in enumerate(self.queue):
            if pid == packet_id:
                new_q = deque()
                for j, item in enumerate(self.queue):
                    if j != idx:
                        new_q.append(item)
                self.queue = new_q
                self.total_bytes -= size
                return size

        return None


class SwitchState:
    """每个输出端口独立 FIFO；port_capacity_bytes 为单端口容量（与拓扑节点 buffer_size_bytes 一致）。"""

    def __init__(self, node: Node, port_capacity_bytes: int):
        self.node = node
        self.port_states: Dict[int, PortState] = {}
        self._port_capacity: int = port_capacity_bytes

    def get_port(self, link_id: int) -> PortState:
        if link_id not in self.port_states:
            self.port_states[link_id] = PortState(self._port_capacity)
        return self.port_states[link_id]

