"""
NetSched Cup — 静态路由表构建

为每个源节点计算到所有目的节点的 hop 最短路集合，并收集所有等长最短路上的第一跳 `link_id` 候选列表。
"""

from __future__ import annotations

from collections import deque, defaultdict
from typing import Dict, List

from config_loader import Topology


def build_routing_table(topology: Topology) -> Dict[int, Dict[int, List[int]]]:
    """
    返回：node_id -> (dst_node -> [next_hop_link_ids])
    """
    routing_table: Dict[int, Dict[int, List[int]]] = {}

    all_nodes = list(topology.nodes.keys())
    for src in all_nodes:
        # BFS 计算 hop 最短距离
        dist: Dict[int, int] = {src: 0}
        prev: Dict[int, List[tuple]] = defaultdict(list)  # v -> [(u, link_id)]
        q: deque = deque([src])

        while q:
            u = q.popleft()
            d = dist[u]
            for link_id, v in topology.adjacency.get(u, []):
                if v not in dist:
                    dist[v] = d + 1
                    q.append(v)
                if dist[v] == d + 1:
                    prev[v].append((u, link_id))

        table_for_src: Dict[int, List[int]] = {}
        for dst in dist.keys():
            if dst == src:
                continue
            # 通过反向遍历 prev 图，收集所有从 src 出发的第一跳 link_id
            first_hops: List[int] = []
            stack = [dst]
            seen = {dst}
            while stack:
                v = stack.pop()
                for u, link_id in prev.get(v, []):
                    if u == src:
                        if link_id not in first_hops:
                            first_hops.append(link_id)
                    elif u not in seen:
                        seen.add(u)
                        stack.append(u)
            if first_hops:
                table_for_src[dst] = first_hops

        routing_table[src] = table_for_src

    return routing_table

