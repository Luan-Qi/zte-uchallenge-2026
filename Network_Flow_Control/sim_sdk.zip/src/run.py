import argparse
import ast
import hashlib
import importlib.machinery
import importlib.util
import json
import multiprocessing
import os
import queue as py_queue
import shutil
import sys
import time
import zipfile
from pathlib import Path
from typing import Optional, Type

from sim_api import HostStrategy, SwitchStrategy

MAX_INFO_LEN = 50
INTERNAL_JUDGE_MODULES = {
    p.stem for p in Path(__file__).resolve().parent.glob("*.py") if p.stem != "sim_api"
}
DYNAMIC_IMPORT_MODULES = {"importlib", "builtins"}


def install_strategy(code_path: str, target_dir: str) -> bool:
    """
    安装选手策略到 src/strategies/strategies_api.py

    支持两种输入：
    - .py：直接复制该文件
    - .zip：从压缩包中提取一个策略文件（优先 strategies_api.py，否则取第一个 .py）
    """
    os.makedirs(target_dir, exist_ok=True)
    dest_path = os.path.join(target_dir, "strategies_api.py")

    if code_path.lower().endswith(".py"):
        if not os.path.isfile(code_path):
            return False
        shutil.copyfile(code_path, dest_path)
        print(f"已安装策略: {code_path} -> {dest_path}")
        return True

    if not code_path.lower().endswith(".zip"):
        return False

    if not os.path.isfile(code_path):
        return False

    with zipfile.ZipFile(code_path, "r") as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        py_files = [n for n in names if n.lower().endswith(".py")]
        if not py_files:
            return False
        # 优先 strategies_api.py（不要求路径），否则退化为第一个 .py
        chosen = None
        for n in py_files:
            if os.path.basename(n).lower() == "strategies_api.py":
                chosen = n
                break
        if chosen is None:
            chosen = py_files[0]
        with z.open(chosen) as source, open(dest_path, "wb") as target:
            shutil.copyfileobj(source, target)
        print(f"已安装策略: {code_path}:{chosen} -> {dest_path}")
        return True


def dumpResult(score, info, output_path="output/results.json"):
    p = Path(output_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(
            {
                "source": score,  # todo: 后期要和接口人说明将这个改为 score，现在先不动
                "info": info,
            },
            f,
            indent=4,
            ensure_ascii=False,
        )


def clean():
    shutil.rmtree("./src/strategies")


def sanitize_info(info) -> str:
    text = str(info) if info is not None else ""
    return text[:MAX_INFO_LEN]


def _forbidden_judge_import(module_name: Optional[str]) -> Optional[str]:
    if not module_name:
        return None
    parts = module_name.split(".")
    root = parts[0]
    if root in INTERNAL_JUDGE_MODULES:
        return module_name
    if root == "src" and len(parts) >= 2 and parts[1] in INTERNAL_JUDGE_MODULES.union({"sim_api"}):
        return module_name
    return None


def _dynamic_import_violation(message: str) -> tuple[bool, str]:
    return (
        False,
        f"策略源码静态检查失败：{message}；"
        "禁止通过动态导入或模块缓存绕过 `sim_api` 限制，否则视为作弊",
    )


def validate_strategy_imports(strategy_path: str) -> tuple[bool, str]:
    try:
        source = Path(strategy_path).read_text(encoding="utf-8")
    except Exception as e:
        return False, f"策略源码静态检查失败：无法读取策略文件: {e}"

    try:
        tree = ast.parse(source, filename=strategy_path)
    except SyntaxError:
        # 语法错误继续交给后续真实加载阶段报更具体的导入/行号信息
        return True, ""

    sys_aliases = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root_name = alias.name.split(".")[0]
                if root_name in DYNAMIC_IMPORT_MODULES:
                    return _dynamic_import_violation(
                        f"禁止导入动态导入相关模块 `{alias.name}`"
                    )
                if root_name == "sys":
                    sys_aliases.add(alias.asname or "sys")
                bad = _forbidden_judge_import(alias.name)
                if bad is not None:
                    return (
                        False,
                        f"策略源码静态检查失败：禁止导入判题器内部模块 `{bad}`；"
                        "仅允许导入 `sim_api`，否则视为作弊",
                    )
        elif isinstance(node, ast.ImportFrom):
            if node.level and node.level > 0:
                return (
                    False,
                    "策略源码静态检查失败：禁止使用相对导入；"
                    "仅允许通过 `sim_api` 使用判题器公开接口，否则视为作弊",
                )
            module_root = (node.module or "").split(".")[0]
            if module_root in DYNAMIC_IMPORT_MODULES:
                return _dynamic_import_violation(
                    f"禁止导入动态导入相关模块 `{node.module}`"
                )
            if module_root == "sys":
                sys_aliases.add("sys")
                for alias in node.names:
                    if alias.name == "modules":
                        return _dynamic_import_violation("禁止访问 `sys.modules`")
            bad = _forbidden_judge_import(node.module)
            if bad is not None:
                return (
                    False,
                    f"策略源码静态检查失败：禁止导入判题器内部模块 `{bad}`；"
                    "仅允许导入 `sim_api`，否则视为作弊",
                )
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == "__import__":
                return _dynamic_import_violation("禁止调用 `__import__`")
            if (
                isinstance(node.func, ast.Attribute)
                and node.func.attr == "__import__"
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id in {"builtins", "__builtins__"}
            ):
                return _dynamic_import_violation("禁止调用 `builtins.__import__`")
            if (
                isinstance(node.func, ast.Attribute)
                and node.func.attr == "import_module"
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == "importlib"
            ):
                return _dynamic_import_violation("禁止调用 `importlib.import_module`")
        elif isinstance(node, ast.Name):
            if node.id == "__builtins__":
                return _dynamic_import_violation("禁止访问 `__builtins__`")
        elif isinstance(node, ast.Attribute):
            if (
                node.attr == "modules"
                and isinstance(node.value, ast.Name)
                and node.value.id in sys_aliases
            ):
                return _dynamic_import_violation("禁止访问 `sys.modules`")

    return True, ""


def is_dataset_dir(path: str) -> bool:
    """判断目录是否为单个数据集目录。"""
    return os.path.isdir(path) and os.path.isfile(os.path.join(path, "topology.json")) and os.path.isfile(
        os.path.join(path, "traffic.csv")
    )


def collect_dataset_dirs(root_dir: str) -> list[str]:
    """
    收集要运行的数据集目录。

    语义：
    - 若 root_dir 本身包含 topology.json 和 traffic.csv，则仅运行该目录；
    - 否则将其视为“数据集集合目录”，只检查其第一层子目录，筛出其中是数据集的目录。
    """
    if not os.path.isdir(root_dir):
        return []
    if is_dataset_dir(root_dir):
        return [root_dir]

    dataset_dirs = []
    for name in sorted(os.listdir(root_dir)):
        child = os.path.join(root_dir, name)
        if is_dataset_dir(child):
            dataset_dirs.append(child)
    return dataset_dirs


def parser_args():
    parser = argparse.ArgumentParser(
        description="NetSched Cup — 高性能网络流量调度仿真器"
    )
    parser.add_argument(
        "--code",
        "-S",
        required=True,
        help="选手策略文件路径 (.py)，需在同一文件中定义 MyHostStrategy / MySwitchStrategy",
    )
    parser.add_argument(
        "--output",
        "-o",
        default="output/results.json",
        help="评分结果输出路径 (默认: output/results.json)",
    )
    parser.add_argument(
        "--dataset",
        default=None,
        help=(
            "数据集目录或数据集集合目录。若目录内直接包含 topology.json 和 traffic.csv，则仅运行该数据集；"
            "否则扫描该目录下一层子目录中的所有数据集。不传则扫描 datasets/。"
        ),
    )
    parser.add_argument(
        "--log",
        "-l",
        default="output/",
        help="输出目录（结果与日志均输出到该目录，默认: output/）",
    )
    parser.add_argument(
        "--event_log",
        action="store_true",
        help="开启详细事件日志（sim_log.jsonl）；默认关闭以节省磁盘空间",
    )
    parser.add_argument(
        "--timeout",
        "-t",
        type=float,
        default=600.0,
        help="仿真器运行实际时间限制（秒），超时后终止仿真并仅对已完成的流计分 (默认: 600)",
    )
    parser.add_argument(
        "--local",
        action="store_true",
        help="本地调试模式：会调用策略 on_sim_end；默认（不加本参数）为线上测评模式，不调用 on_sim_end",
    )

    return parser.parse_args()


def run(data_dir, args, queue):
    ds_name = os.path.basename(os.path.normpath(data_dir)) or str(data_dir)
    try:
        # ── 解析数据目录与文件路径 ──
        topology_path = os.path.join(data_dir, "topology.json")
        traffic_path = os.path.join(data_dir, "traffic.csv")

        if not os.path.isdir(data_dir):
            print(f"错误: 数据目录不存在: {data_dir}", file=sys.stderr)
            return queue.put(
                {"dataset": ds_name, "score": 0.0, "info": sanitize_info(f"错误: 数据目录不存在: {data_dir}")}
            )
        if not os.path.isfile(topology_path):
            print(f"错误: 未在数据目录中找到 topology.json: {topology_path}", file=sys.stderr)
            return queue.put(
                {
                    "dataset": ds_name,
                    "score": 0.0,
                    "info": sanitize_info(f"错误: 未在数据目录中找到 topology.json: {topology_path}"),
                }
            )
        if not os.path.isfile(traffic_path):
            print(f"错误: 未在数据目录中找到 traffic.csv: {traffic_path}", file=sys.stderr)
            return queue.put(
                {
                    "dataset": ds_name,
                    "score": 0.0,
                    "info": sanitize_info(f"错误: 未在数据目录中找到 traffic.csv: {traffic_path}"),
                }
            )

        # ── 解析并加载策略文件（如有指定） ──
        host_strategy_cls: Type[HostStrategy]
        switch_strategy_cls: Type[SwitchStrategy]

        strategy_path = os.path.join(os.path.dirname(__file__), "strategies", "strategies_api.py")
        if not os.path.isfile(strategy_path):
            print(f"错误: 策略文件不存在: {strategy_path}", file=sys.stderr)
            return queue.put(
                {"dataset": ds_name, "score": 0.0, "info": sanitize_info(f"策略文件不存在: {strategy_path}")}
            )

        # 为策略文件构造一个稳定但不冲突的模块名
        mod_hash = hashlib.sha1(strategy_path.encode("utf-8")).hexdigest()[:8]
        mod_name = f"user_strategy_{mod_hash}"

        try:
            loader = importlib.machinery.SourceFileLoader(mod_name, strategy_path)
            spec = importlib.util.spec_from_loader(mod_name, loader)
            module = importlib.util.module_from_spec(spec)
            assert spec is not None and spec.loader is not None
            spec.loader.exec_module(module)  # type: ignore[arg-type]
            sys.modules[mod_name] = module
        except Exception as e:
            print(f"错误: 加载策略文件失败: {strategy_path}", file=sys.stderr)
            print(f"原因: {e}", file=sys.stderr)
            return queue.put(
                {"dataset": ds_name, "score": 0.0, "info": sanitize_info(f"加载策略文件失败: {strategy_path}")}
            )

        # 从模块中获取约定类名
        host_cls = getattr(module, "MyHostStrategy", None)
        switch_cls = getattr(module, "MySwitchStrategy", None)
        if host_cls is None or switch_cls is None:
            print("错误: 策略文件中必须定义 MyHostStrategy 和 MySwitchStrategy 类。", file=sys.stderr)
            return queue.put(
                {
                    "dataset": ds_name,
                    "score": 0.0,
                    "info": sanitize_info("策略文件中必须定义 MyHostStrategy 和 MySwitchStrategy 类。"),
                }
            )

        # 类型检查：必须继承框架提供的接口
        if not issubclass(host_cls, HostStrategy):
            print("错误: MyHostStrategy 必须继承 sim_api.HostStrategy。", file=sys.stderr)
            return queue.put(
                {"dataset": ds_name, "score": 0.0, "info": sanitize_info("MyHostStrategy 必须继承 sim_api.HostStrategy。")}
            )
        if not issubclass(switch_cls, SwitchStrategy):
            print("错误: MySwitchStrategy 必须继承 sim_api.SwitchStrategy。", file=sys.stderr)
            return queue.put(
                {
                    "dataset": ds_name,
                    "score": 0.0,
                    "info": sanitize_info("MySwitchStrategy 必须继承 sim_api.SwitchStrategy。"),
                }
            )

        host_strategy_cls = host_cls
        switch_strategy_cls = switch_cls
        strategy_desc = strategy_path

        # 须在策略校验通过后导入：simulator 顶层会导入 strategies.strategies_api
        from config_loader import load_topology, load_traffic
        from simulator import Simulator

        # ── 加载配置 ──
        print("=" * 60)
        print("  NetSched Cup — 网络流量调度仿真器")
        print("=" * 60)
        print(f"\n  使用策略文件: {strategy_desc}")

        print(f"\n[1/4] 加载拓扑: {topology_path}")
        topology = load_topology(topology_path)
        hosts = topology.get_hosts()
        switches = topology.get_switches()
        print(
            f"      节点数: {len(topology.nodes)} ({len(hosts)} hosts + {len(switches)} switches)"
        )
        print(f"      链路数: {len(topology.links)}")

        print(f"\n[2/4] 加载流量: {traffic_path}")
        flows = load_traffic(traffic_path)
        print(f"      流数量: {len(flows)}")
        total_bytes = sum(f.size_bytes for f in flows)
        print(
            f"      总数据量: {total_bytes:,} 字节 "
            f"({total_bytes / 1024 / 1024:.2f} MB)"
        )

        # ── 初始化仿真器 ──
        event_log_enabled = bool(getattr(args, "event_log", False))
        online_mode = not bool(getattr(args, "local", False))
        sim_time_us = topology.global_config.simulation_time_us

        print("\n[3/4] 初始化仿真器")
        print(f"      事件日志: {'开启' if event_log_enabled else '关闭'}")
        print(f"      在线测评模式: {'是' if online_mode else '否'}")
        print(
            f"      仿真时间限制: {sim_time_us:.0f} μs "
            f"({sim_time_us / 1000:.3f} ms)"
        )
        print(f"      真实时间限制: {args.timeout} s")

        sim = Simulator(
            topology=topology,
            flows=flows,
            wall_timeout_seconds=args.timeout,
            log_enabled=event_log_enabled,
            online_mode=online_mode,
            host_strategy_cls=host_strategy_cls,
            switch_strategy_cls=switch_strategy_cls,
        )

        # ── 运行仿真 ──
        print("\n[4/4] 开始仿真...")
        wall_start = time.time()
        result = sim.run()
        wall_elapsed = time.time() - wall_start

        # ── 输出结果 ──
        print(f"\n{'=' * 60}")
        reason = result.get("termination_reason")
        if reason == "wall_timeout":
            print("  真实时间超限终止!")
        elif reason == "sim_time_limit":
            print("  仿真时间到达上限终止!")
        elif reason == "event_queue_empty":
            print("  事件队列耗尽终止!")
        else:
            print("  仿真完成!")
        print(f"{'=' * 60}")
        print(f"\n  仿真时间:   {result.get('simulation_time_us', 0) / 1000:.3f} ms")
        print(f"  真实时间:   {wall_elapsed:.3f} s")

        # 事件次数统计
        event_counts = result.get("event_counts") or {}
        if event_counts:
            print("\n  ── 事件次数 ──")
            for name in sorted(event_counts.keys()):
                print(f"  {name:<14} {int(event_counts[name]):>10}")

        # 包统计
        pkt = result.get("packet_stats") or {}
        if pkt:
            print("\n  ── 包统计 ──")
            print(f"  总包数:         {int(pkt.get('total_packets', 0))}")
            print(f"  总数据包数:     {int(pkt.get('total_data_packets', 0))}")
            print(f"  总控制包数:     {int(pkt.get('total_ctrl_packets', 0))}")
            print(f"  原始数据包数:   {int(pkt.get('original_data_packets', 0))}")
            print(f"  重发数据包数:   {int(pkt.get('retransmitted_data_packets', 0))}")
            print(f"  丢失数据包数:   {int(pkt.get('dropped_data_packets', 0))}")
            print(f"  丢失控制包数:   {int(pkt.get('dropped_ctrl_packets', 0))}")
            print(f"  成功交付数据包数:{int(pkt.get('delivered_data_packets', 0))}")
        print("\n  ── 评分报告 ──")
        print(f"  最终得分:     {result.get('final_score', 0):.4f}")
        print(f"\n  总流数:       {result.get('total_flows', 0)}")
        print(f"  已完成:       {result.get('completed_flows', 0)}")
        print(f"  超时违约:     {result.get('deadline_violations', 0)}")

        # 输出每条流的详情
        flow_details = result.get("flow_details", {})
        if flow_details:
            print("\n  ── 流详情 ──")
            # 使用纯 ASCII 列名，避免全角字符导致终端宽度计算不一致
            print(
                f"  {'FlowID':>8} {'Start_us':>12} {'End_us':>12} "
                f"{'Deadline_us':>12} {'FCT_us':>12} {'Ideal_us':>12} "
                f"{'Prio':>6} {'Delivered(B)':>16} {'Ratio':>8}"
            )
            print(f"  {'-' * 112}")
            for fid, detail in sorted(flow_details.items(), key=lambda x: int(x[0])):
                start_str = f"{detail.get('start_time_us', 0.0):.1f}"
                end_us = detail.get("end_time_us", 0.0)
                end_str = f"{end_us:.1f}" if end_us > 0 else "N/A"
                deadline_str = f"{detail.get('deadline_us', 0.0):.1f}"
                fct_us = detail.get("fct_us", 0.0)
                fct_str = f"{fct_us:.1f}" if fct_us > 0 and fct_us < float("inf") else "inf"
                ideal_str = f"{detail.get('ideal_fct_us', 0.0):.1f}"
                # 优先展示“已交付前缀字节数”（未完成流也有意义）；若不存在则回退到旧字段
                delivered_bytes = detail.get(
                    "delivered_prefix_bytes", detail.get("delivered_bytes", 0)
                )
                delivered_ratio = detail.get(
                    "delivered_prefix_ratio", detail.get("delivered_ratio", 0.0)
                )
                delivered_str = f"{delivered_bytes:,}"
                ratio_str = f"{delivered_ratio * 100:5.1f}%"
                print(
                    f"  {fid:>8} {start_str:>12} {end_str:>12} "
                    f"{deadline_str:>12} {fct_str:>12} {ideal_str:>12} "
                    f"{detail['priority']:>6} {delivered_str:>16} {ratio_str:>8}"
                )

        # 保存结果
        # `data_dir` 可能以 `/` 结尾（如 datasets/leaf-spine-32/），避免 split 后落到空字符串导致输出为 `output/_result.json`
        curr_log_result_path = args.log + ds_name + "_result.json"
        p = Path(curr_log_result_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        print(f"\n  结果已保存: {p}")

        # 保存日志
        if event_log_enabled:
            sim.logger.export(args.log)
            print(f"  日志已保存: {args.log}")

        return queue.put(
            {
                "dataset": ds_name,
                "score": float(result.get("final_score", 0.0)),
                "info": sanitize_info("仿真运行成功"),
            }
        )
    except AssertionError as e:
        # 断言错误：既包括内部错误（消息以【内部错误】开头），也包括选手策略错误
        msg = str(e) or "未知断言失败"
        print(f"断言失败: {msg}", file=sys.stderr)
        return queue.put({"dataset": ds_name, "score": 0.0, "info": sanitize_info(msg)})
    except Exception as e:
        # 其它未捕获异常统一视为内部错误
        msg = f"【内部错误】仿真过程中发生未捕获异常: {e}"
        print(msg, file=sys.stderr)
        return queue.put({"dataset": ds_name, "score": 0.0, "info": sanitize_info(msg)})


if __name__ == "__main__":
    args = parser_args()
    if not install_strategy(args.code, "./src/strategies"):
        dumpResult(0, "策略安装失败：请传入 .py 文件或包含 .py 的 .zip 文件", args.output)
        sys.exit(1)
    ok, msg = validate_strategy_imports("./src/strategies/strategies_api.py")
    if not ok:
        dumpResult(0, msg, args.output)
        clean()
        sys.exit(1)

    queue = multiprocessing.Queue()
    processes = []
    if args.dataset:
        ds_dir = args.dataset
        if not os.path.isdir(ds_dir):
            dumpResult(0, f"未找到数据集目录: {ds_dir}", args.output)
            sys.exit(1)
        dataset_dirs = collect_dataset_dirs(ds_dir)
        if not dataset_dirs:
            dumpResult(0, f"未在目录中找到数据集: {ds_dir}", args.output)
            sys.exit(1)
    else:
        datasets_root = "datasets"
        dataset_dirs = collect_dataset_dirs(datasets_root)
        if not dataset_dirs:
            dumpResult(0, f"未在目录中找到数据集: {datasets_root}", args.output)
            sys.exit(1)

    for ds_dir in dataset_dirs:
        p = multiprocessing.Process(target=run, args=(ds_dir, args, queue))
        processes.append(p)
        p.start()
    for p in processes:
        p.join()

    # 初始化每个数据集的默认结果：若子进程崩溃导致无回传，保留 0 分 + 进程崩溃
    results_by_dataset = {}
    for ds_dir in dataset_dirs:
        ds_name = os.path.basename(os.path.normpath(ds_dir)) or ds_dir
        results_by_dataset[ds_name] = {"score": 0.0, "info": sanitize_info("进程崩溃")}

    # 读取已回传结果（子进程可能崩溃，回传条数可能小于进程数）
    while True:
        try:
            payload = queue.get_nowait()
        except py_queue.Empty:
            break

        if isinstance(payload, dict):
            ds_name = payload.get("dataset")
            if ds_name in results_by_dataset:
                score = float(payload.get("score", 0.0))
                info = sanitize_info(payload.get("info", ""))
                results_by_dataset[ds_name] = {"score": score, "info": info}

    # 最终得分按数据集均值
    final_scores = [v["score"] for v in results_by_dataset.values()]
    final_score = (sum(final_scores) / len(final_scores)) if final_scores else 0.0

    # 最终 info：仅按数据集顺序拼接各子 info（不含数据集名），用 | 分隔
    infos = [results_by_dataset[ds]["info"] for ds in sorted(results_by_dataset.keys())]
    final_info = "|".join(infos) if infos else "无数据集"

    dumpResult(final_score, final_info, args.output)

    clean()
