"""
NetSched Cup — 拓扑与流量配置加载器

解析 topology.json 和 traffic.csv，构建仿真所需的
拓扑图（节点 + 链路 + 邻接表）和流量需求列表。
"""

import json
import csv
from dataclasses import dataclass, field
from typing import List, Dict


# ─────────────────── 全局配置 ───────────────────

@dataclass
class GlobalConfig:
    """仿真全局参数"""
    simulation_time_us: float = 10_000_000.0  # 仿真总时长（微秒）
    default_link_bandwidth_gbps: float = 10 # 默认链路带宽（Gbps）
    default_link_latency_us: float = 5      # 默认链路时延（微秒）
    default_host_buffer_size_bytes: int = 1_048_576   # 默认 host 缓冲区大小（字节）
    default_switch_buffer_size_bytes: int = 1_048_576  # 默认交换机每个输出端口队列容量（字节）


# ─────────────────── 节点 ───────────────────

@dataclass
class Node:
    """网络节点（主机或交换机）"""
    id: int
    type: str                               # "host" 或 "switch"
    buffer_size_bytes: int = 1_048_576      # host：接收缓冲总容量；switch：每个输出端口 FIFO 容量（各端口独立、相同）

    @property
    def is_host(self) -> bool:
        return self.type == "host"

    @property
    def is_switch(self) -> bool:
        return self.type == "switch"


# ─────────────────── 链路 ───────────────────

@dataclass
class Link:
    """物理链路（唯一 link_id）；src/dst 与 JSON 一致，仅用于标识两端，传输参数双向相同。"""
    id: int
    src: int                                # JSON 中的端点之一
    dst: int                                # JSON 中的另一端点
    bandwidth_gbps: float = 10.0            # 带宽（Gbps）
    latency_us: float = 5.0                 # 传播时延（微秒）

    @property
    def bandwidth_bytes_per_us(self) -> float:
        """带宽转换为 字节/微秒"""
        return self.bandwidth_gbps * 1e9 / 8 / 1e6  # Gbps → bytes/μs

    def transmission_delay_us(self, packet_size_bytes: int) -> float:
        """计算传输时延（微秒）"""
        return packet_size_bytes / self.bandwidth_bytes_per_us


# ─────────────────── 流量需求 ───────────────────

@dataclass
class FlowDemand:
    """流量需求（对应 traffic.csv 中的一行）；时间与仿真内核一致，均为微秒。"""
    flow_id: int
    src_node: int
    dst_node: int
    size_bytes: int
    start_time_us: float
    priority: int = 1
    deadline_us: float = float("inf")


# ─────────────────── 拓扑 ───────────────────

@dataclass
class Topology:
    """完整的网络拓扑"""
    global_config: GlobalConfig
    nodes: Dict[int, Node] = field(default_factory=dict)
    links: Dict[int, Link] = field(default_factory=dict)
    # 邻接表: node_id -> [(link_id, neighbor_id), ...]
    adjacency: Dict[int, List[tuple]] = field(default_factory=dict)

    def get_links_between(self, src: int, dst: int) -> List[Link]:
        """获取两节点间的所有链路"""
        result = []
        for link_id, neighbor in self.adjacency.get(src, []):
            if neighbor == dst:
                result.append(self.links[link_id])
        return result

    def get_neighbors(self, node_id: int) -> List[int]:
        """获取节点的所有邻居"""
        return [n for _, n in self.adjacency.get(node_id, [])]

    def get_outgoing_links(self, node_id: int) -> List[Link]:
        """获取节点的所有出链路"""
        return [self.links[lid] for lid, _ in self.adjacency.get(node_id, [])]

    def get_hosts(self) -> List[Node]:
        """获取所有主机节点"""
        return [n for n in self.nodes.values() if n.is_host]

    def get_switches(self) -> List[Node]:
        """获取所有交换机节点"""
        return [n for n in self.nodes.values() if n.is_switch]


# ─────────────────── 加载函数 ───────────────────

def _load_json_with_comments(path: str) -> dict:
    """
    读取允许包含 // 行内注释 的 JSON 文件，并返回解析结果。

    约定：
    - 以 // 开头的整行视为注释行，整体忽略；
    - 行中间出现的 // 及其之后的内容也视为注释；
    - 当前实现假定 JSON 字符串字面量中不会包含 //，适用于本项目的配置文件。
    """
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    cleaned_lines: List[str] = []
    for line in lines:
        stripped = line.lstrip()
        if stripped.startswith("//"):
            continue
        # 去掉行内注释（假定 // 仅用于注释）
        comment_pos = line.find("//")
        if comment_pos != -1:
            line = line[:comment_pos]
        cleaned_lines.append(line)

    cleaned = "".join(cleaned_lines)
    return json.loads(cleaned)


def load_topology(path: str) -> Topology:
    """
    解析 topology.json，构建 Topology 对象。

    支持在 JSON 中使用 // 注释（整行或行尾），方便为拓扑文件添加说明。
    JSON 结构格式参见 README §3.1。
    """
    data = _load_json_with_comments(path)

    # 全局配置
    gc_data = data.get("global_config", {})
    global_config = GlobalConfig(
        simulation_time_us=float(gc_data.get("simulation_time_us", 10_000_000)),
        default_link_bandwidth_gbps=gc_data.get("default_link_bandwidth_gbps", 10),
        default_link_latency_us=gc_data.get("default_link_latency_us", 5),
        default_host_buffer_size_bytes=gc_data.get("default_host_buffer_size_bytes", 1_048_576),
        default_switch_buffer_size_bytes=gc_data.get("default_switch_buffer_size_bytes", 1_048_576),
    )

    topo = Topology(global_config=global_config)

    # 节点
    for n in data.get("nodes", []):
        node_type = n["type"]
        if "buffer_size_bytes" in n:
            buf_size = n["buffer_size_bytes"]
        else:
            if node_type == "host":
                buf_size = global_config.default_host_buffer_size_bytes
            elif node_type == "switch":
                buf_size = global_config.default_switch_buffer_size_bytes
            else:
                raise ValueError(
                    f"Topology error: 未知节点类型 {node_type!r}，无法确定默认 buffer_size_bytes"
                )
        node = Node(
            id=n["id"],
            type=node_type,
            buffer_size_bytes=buf_size,
        )
        topo.nodes[node.id] = node
        topo.adjacency.setdefault(node.id, [])

    # 每条 JSON 链路：单一 link_id，两端邻接表各挂一次（全双工由数据面按「节点×link」维护）
    for l in data.get("links", []):
        bw = l.get("bandwidth_gbps", global_config.default_link_bandwidth_gbps)
        lat = l.get("latency_us", global_config.default_link_latency_us)
        link = Link(
            id=l["id"],
            src=l["src"],
            dst=l["dst"],
            bandwidth_gbps=bw,
            latency_us=lat,
        )
        topo.links[link.id] = link
        topo.adjacency.setdefault(link.src, []).append((link.id, link.dst))
        topo.adjacency.setdefault(link.dst, []).append((link.id, link.src))

    # 拓扑校验：每个 host 必须有且仅有一个邻居，且该邻居为 switch
    for node in topo.get_hosts():
        neighbors = topo.get_neighbors(node.id)
        if len(neighbors) != 1:
            raise ValueError(
                f"【内部错误】拓扑错误：host {node.id} 必须且只能连接 1 个交换机，"
                f"但当前有 {len(neighbors)} 个邻居：{sorted(neighbors)}"
            )
        neigh_id = neighbors[0]
        neigh_node = topo.nodes.get(neigh_id)
        if neigh_node is None or not neigh_node.is_switch:
            raise ValueError(
                f"【内部错误】拓扑错误：host {node.id} 的唯一邻居必须是交换机，"
                f"但 neighbor {neigh_id} 不是交换机"
            )

    return topo


def load_traffic(path: str) -> List[FlowDemand]:
    """
    解析 traffic.csv，返回流量需求列表。

    CSV 格式：
    FlowID, SrcNode, DstNode, SizeBytes, StartTimeUs, Priority, DeadlineUs
    （StartTimeUs / DeadlineUs 为从仿真 t=0 起的绝对时间，单位微秒）
    """
    flows = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            flow = FlowDemand(
                flow_id=int(row["FlowID"]),
                src_node=int(row["SrcNode"]),
                dst_node=int(row["DstNode"]),
                size_bytes=int(row["SizeBytes"]),
                start_time_us=float(row["StartTimeUs"]),
                priority=int(row.get("Priority", 1)),
                deadline_us=float(row.get("DeadlineUs", "inf")),
            )
            flows.append(flow)

    return sorted(flows, key=lambda f: f.start_time_us)
