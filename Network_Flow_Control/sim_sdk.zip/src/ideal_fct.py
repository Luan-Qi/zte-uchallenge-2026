"""
NetSched Cup — 理想 FCT 估计

使用最短传播时延与瓶颈最大流近似计算理想 FCT 下界：
- 最短传播时延：仅按 `latency_us` 的 Dijkstra
- 最大瓶颈带宽：在带宽图上计算 `s->t` 最大流 `C*`
- `ideal_fct ~= L* + size_bytes / C*`
"""

from __future__ import annotations

import heapq
import math
from collections import defaultdict, deque
from typing import Dict

from config_loader import FlowDemand, Topology
from packet import DATA_HEADER_BYTES, MAX_PAYLOAD


def compute_ideal_fct(topology: Topology, fd: FlowDemand) -> float:
    """计算单条流的 ideal FCT 下界。"""
    src = fd.src_node
    dst = fd.dst_node

    # 1) 计算最短传播时延 L*（只按 latency_us 加权的最短路径）
    L_star = shortest_latency_us(topology, src, dst)

    # 2) 计算 s->t 最大流 C*（字节/微秒），作为最小 cut 总带宽
    C_star = max_flow_capacity(topology, src, dst)

    if not math.isfinite(L_star) or C_star <= 0:
        return float("inf")

    # 3) 序列化时延按“线速字节数”估算：
    #    DATA 每包有固定头部 DATA_HEADER_BYTES，payload 上限为 MAX_PAYLOAD。
    packet_count = math.ceil(fd.size_bytes / MAX_PAYLOAD) if fd.size_bytes > 0 else 0
    wire_bytes = fd.size_bytes + packet_count * DATA_HEADER_BYTES

    return L_star + wire_bytes / C_star


def shortest_latency_us(topology: Topology, src: int, dst: int) -> float:
    """仅按链路 latency_us 计算 src->dst 的最短传播时延。"""
    if src == dst:
        return 0.0

    # Dijkstra
    dist: Dict[int, float] = {src: 0.0}
    pq: list[tuple[float, int]] = [(0.0, src)]
    visited: set[int] = set()

    while pq:
        d, u = heapq.heappop(pq)
        if u in visited:
            continue
        visited.add(u)
        if u == dst:
            return d
        for link_id, v in topology.adjacency.get(u, []):
            link = topology.links[link_id]
            # 只考虑带宽正数的链路
            if link.bandwidth_bytes_per_us <= 0:
                continue
            nd = d + link.latency_us
            if nd < dist.get(v, float("inf")):
                dist[v] = nd
                heapq.heappush(pq, (nd, v))

    return float("inf")


def max_flow_capacity(topology: Topology, src: int, dst: int) -> float:
    """在带宽图上计算单流 s->t 的最大流量 C*（字节/微秒）。"""
    if src == dst:
        return float("inf")

    # 无向物理链路：对 (u,v) 建双向有向边，容量各为 cap（与单 link_id 拓扑一致）
    residual: Dict[int, Dict[int, float]] = defaultdict(dict)
    for link in topology.links.values():
        u = link.src
        v = link.dst
        cap = float(link.bandwidth_bytes_per_us)
        if cap <= 0:
            continue
        residual[u][v] = residual[u].get(v, 0.0) + cap
        residual[v][u] = residual[v].get(u, 0.0) + cap

    def bfs() -> tuple[float, Dict[int, int]]:
        """在残量网络上找一条增广路径，返回流量和父节点表。"""
        parent: Dict[int, int] = {src: -1}
        # (节点, 到该点的最小残量)
        q: deque[tuple[int, float]] = deque([(src, float("inf"))])
        while q:
            u, flow = q.popleft()
            for v, cap in residual.get(u, {}).items():
                if cap > 1e-12 and v not in parent:
                    parent[v] = u
                    new_flow = min(flow, cap)
                    if v == dst:
                        return new_flow, parent
                    q.append((v, new_flow))
        return 0.0, parent

    max_flow = 0.0
    while True:
        path_flow, parent = bfs()
        if path_flow <= 0.0:
            break
        max_flow += path_flow
        # 反向更新残量网络
        v = dst
        while v != src:
            u = parent[v]
            residual[u][v] -= path_flow
            residual[v][u] = residual[v].get(u, 0.0) + path_flow
            v = u

    return max_flow

