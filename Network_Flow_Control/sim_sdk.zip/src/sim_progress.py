"""
NetSched Cup — 仿真进度输出

在仿真运行期间输出进度条与内存占用（RSS）峰值。
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass


@dataclass
class ProgressReporter:
    bar_len: int = 30
    tick_interval_s: float = 0.5
    printed_two_lines: bool = False
    last_progress_wall: float = 0.0
    peak_rss_kb: int = 0

    def _get_current_rss_kb(self) -> int:
        """读取当前进程 RSS（kB），来自 /proc/self/status::VmRSS。"""
        try:
            with open("/proc/self/status", "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        m = re.search(r"VmRSS:\s+(\d+)\s+kB", line)
                        if m:
                            return int(m.group(1))
                        break
        except Exception:
            pass
        return 0

    def tick(
        self,
        *,
        delivered_flow_bytes: int,
        total_flow_bytes: int,
        sim_time_us: float,
        wall_start_s: float,
        now_wall_s: float,
    ) -> None:
        if total_flow_bytes <= 0:
            return
        if now_wall_s - self.last_progress_wall < self.tick_interval_s:
            return
        self.last_progress_wall = now_wall_s

        ratio = min(1.0, delivered_flow_bytes / total_flow_bytes)
        pct = ratio * 100.0
        wall_elapsed_s = now_wall_s - wall_start_s
        sim_time_ms = sim_time_us / 1000.0

        rss_kb = self._get_current_rss_kb()
        if rss_kb > self.peak_rss_kb:
            self.peak_rss_kb = rss_kb
        rss_mb = rss_kb / 1024.0
        peak_mb = self.peak_rss_kb / 1024.0

        filled = int(self.bar_len * ratio)
        bar = "#" * filled + "." * (self.bar_len - filled)

        done_mb = delivered_flow_bytes / (1024 * 1024)
        total_mb = total_flow_bytes / (1024 * 1024)

        if self.printed_two_lines:
            # 上移两行并回到行首，覆盖旧输出
            print("\x1b[2A\r", end="")

        # 第 1 行：进度 + 已交付
        print(
            f"  进度: [{bar}] {pct:5.1f}%  已交付: {done_mb:.2f} MB / {total_mb:.2f} MB",
            end="",
        )
        # 第 2 行：仿真时间/真实时间 + RSS
        print(
            f"\n  仿真时间: {sim_time_ms:8.2f} ms  真实时间: {wall_elapsed_s:6.2f} s"
            f"  内存: RSS {rss_mb:8.2f} MB  峰值 {peak_mb:8.2f} MB",
            flush=True,
        )
        self.printed_two_lines = True

