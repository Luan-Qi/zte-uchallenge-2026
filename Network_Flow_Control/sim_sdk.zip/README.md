# 网络流量调度仿真

## 1. 赛题背景

在高负载、多流并发的数据中心网络中，端到端传输策略（发送速率、拥塞控制、重传）与交换机调度策略（选路、队列调度、主动丢包）共同决定流的完成时间（FCT）与公平性。本赛题提供一个**离散事件网络仿真器**，在可编程环境下评估你的 Host 策略与交换机策略的性能。

- **仿真器职责**：离散事件推进、链路带宽与传播时延、路由、缓冲区容量、乱序接收与流完成判定。
- **选手策略职责**：通过实现 `HostStrategy` 与 `SwitchStrategy`，决定何时发多少数据、如何选路与排队、如何交付与反馈（如 ACK），以在给定拓扑与流量下最大化加权 FCT 得分。

---

## 2. 选手任务

- 在**同一 Python 文件**中实现两个类（类名固定）：
  - `MyHostStrategy(HostStrategy)`：每个 host 一个实例，统一处理该 host 上所有流的发送与接收逻辑。
  - `MySwitchStrategy(SwitchStrategy)`：每个交换机一个实例，负责该交换机所有端口的选路与出队调度。
- 策略**只能**通过 `sim_api.py`：仿真开始前由 `on_sim_start(init)` **注入静态快照**（`HostInitInfo` / `SwitchInitInfo`），运行期再通过 `HostContext` / `SwitchContext` 与仿真器交互，不得直接访问仿真器内部状态或修改除 `PacketView.custom` 以外的只读字段。
- 策略源码中的 `import` **只允许**使用 `sim_api` 访问判题器公开接口；禁止导入 `packet`、`simulator`、`sim_host`、`sim_switch`、`run` 等任何判题器内部模块，也禁止使用相对导入访问判题器代码。进一步地，禁止使用 `importlib`、`builtins.__import__`、`__import__`、`__builtins__`、`sys.modules` 等动态导入或模块缓存机制绕过限制。评测程序会对策略源码做静态检查；违反该限制将**直接拒绝运行，并视为作弊**。
- 各策略回调的调用时机、是否必须实现与参数返回值约束见 **第 5 节《需要实现的接口》**。

---

## 3. 赛题模型

### 3.1 仿真世界观

- **离散事件仿真**：全局仿真时钟单位为**微秒**（`μs`）。内核按时间顺序从优先队列取出事件并处理；**同一时刻**多个事件的先后顺序由实现决定，如需核对可开启 `--event_log` 查看日志顺序。
- **终止**：时钟到达 `simulation_time_us`、事件队列耗尽、或真实时间超过 `--timeout` 时结束；`termination_reason` 含义见 **第 8.1 节**。

### 3.2 拓扑与节点模型


| 节点类型     | 说明                                  | 策略                                           |
| -------- | ----------------------------------- | -------------------------------------------- |
| `Host`   | 每个 host **仅一条**邻接链路（唯一上行链路），连到一台交换机 | 一个 `HostStrategy` 实例，负责该 host 上**所有流**的发送与接收 |
| `Switch` | 多端口，可与多台 host / 其它交换机相连             | 一个 `SwitchStrategy` 实例，负责该交换机**所有端口**的选路与出队  |


- **端口与链路**：本题中 **出向端口与 `link_id` 一一对应**；交换机上有几条邻接链路，就有几个可转发用的出端口（及对应 `FIFO`）。Host 侧唯一的 `link_id` 即其上行「端口」。
- **无重边**：任意两节点间**至多一条**物理链路（无平行多重边）；全双工由链路**两端各自**维护发送占用实现，不通过多条同端点对记录表示。更正式的约定见 **第 10.3 节**。
- **交换机队列**：每个**输出端口**（每条出向 `link_id`）一个独立 `FIFO`，容量均为该节点在拓扑中的 `buffer_size_bytes`，**不按端口数均分**总缓冲池；与 `SwitchInitInfo.buffer_size_bytes` 一致。


### 3.3 链路模型

- **属性**：每条链路有 `bandwidth_gbps` 与 `latency_us`（**传播时延**，微秒）；两个方向传输参数相同。
- **无随机丢包**：仿真**不会**在链路上随机丢包。丢包仅来自策略/AQM、队列满、主机侧处理等。
- **串行链路（实现语义）**：对每一侧「节点 × `link_id`」维护该方向链路的忙闲结束时刻 `busy_until`。
  - 本包**开始发送**时刻：`depart_time = max(当前仿真时刻, 该侧链路的 busy_until)`。
  - **传输时延** `tx_us`：按带宽将整包字节串行送出，`tx_us = size / (带宽换算得到的 字节/μs)`。链路上 `size`：DATA 为 `64B 固定头部 + payload_size`（总长 ≤ `MTU=1500`，即 `payload_size ≤ MAX_PAYLOAD=1436`），CTRL 固定 **64** 字节。
  - 更新：`busy_until = depart_time + tx_us`。
  - **对端收到**时刻：`arrive_time = depart_time + tx_us + latency_us`，内核在该时刻调度 `LINK_ARRIVE`。
- **就绪事件与空闲**：Host 的 `LINK_READY` 调度在时刻 `max(now, 该 host 唯一出链路的 busy_until)`（链路空闲后才能再被询问发送）。交换机某出向链路在完成一次发送后，在 `busy_until`（该包最后一个比特离开发送端）再入队下一次 `LINK_READY`，以便链路上无在传比特后再调用 `on_link_ready`。

### 3.4 报文模型

- **DATA 包**：承载流的实际字节；`payload_size` 不超过 `MAX_PAYLOAD=1436`，并采用 `64B` 固定头部，因此链路等效长度为 `64 + payload_size`（总长不超过 `MTU=1500`）。除只读头字段外，策略可使用可写字典 `custom` 携带任意协议元数据（仿真器不解析语义）。**仅 Host** 在 `on_link_ready` 返回 `DataPacketSpec` 时由仿真器创建 DATA 包。
- **CTRL 包**：不承载流 payload（视图中 `payload_size` 为 0）；链路上**固定占用 64 字节**；同样支持 `custom`。**Host** 可在 `on_link_ready` 返回 `ControlPacketSpec` 创建并发出；**交换机**可在 `on_link_ready` 返回 `ControlPacketSpec` 在对应出端口创建并发出。
- **流量表**：仿真内核根据数据集在特定时刻生成流，流开始时内核投递 `FLOW_START`，在源 host 上调用 `on_flow_arrival`，再调度 `LINK_READY`。

### 3.5 事件驱动与策略回调

下表概括「事件何时发生 → 调用哪个策略接口 → 内核随后做什么」。细粒度约束（断言、Host `request_link_ready()` 与交换机 `request_link_ready(output_port)` 等）见 **第 5 节**。


| 事件类型                   | 调度时机（时间规则）                               | 策略回调                                      | 框架后续动作（典型）                                                                                                                        |
| ---------------------- | ---------------------------------------- | ----------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| `FLOW_START`           | 流量表中该流的 `StartTimeUs`                    | 源 host：`on_flow_arrival`                  | 为该 host 在 `max(now, busy_until)` 调度 `LINK_READY`（唯一出链路）                                                                           |
| `LINK_READY`（host）     | `max(now, busy_until)`；**t=0** 每 host 一次 | `on_link_ready(ctx)`                      | 若返回 `DataPacketSpec` / `ControlPacketSpec` 并完成发送，则在链路再次空闲时再次调度 `LINK_READY`；若返回 `None` 则不自动再调度（否则会导致同一仿真时刻重复触发 on_link_ready 死循环） |
| `LINK_READY`（switch）   | **t=0** 每出端口；之后链路空闲（见 **5.2**）           | `on_link_ready(port, ctx)`                | 发送则触发对端节点的 `LINK_ARRIVE` 并于 `busy_until` 时再调度本该端口 `LINK_READY`                                                                    |
| `LINK_ARRIVE` → host   | 见 3.3                                    | `on_packet_arrival(pkt, ctx)`             | `无`                                                                                                                               |
| `LINK_ARRIVE` → switch | 同上                                       | `on_packet_arrival(pkt, input_port, ctx)` | 入队/丢弃；入队后可触发对应链路的 `LINK_READY`                                                                                                    |
| `CUSTOM_TIMER`         | `now + delay_us`（≥1）                     | `on_timer`                                |                                                                                                                                   |


**端到端示例**：源 host 在 `on_link_ready` 发出 DATA → 经 `tx_us + latency_us` 到达交换机 → `on_packet_arrival` 选择出端口并入队 → 若该出链路空闲则 `on_link_ready` 选中包发出 → … → 目的 host `on_packet_arrival` → 策略 `deliver_packet` 推进流完成。具体多次跳转时，每段链路均重复 3.3 的 `depart_time` / `arrive_time` 计算。

### 3.6 其它行为约定（详见第 5 节）

- **Host 发送**：字节级 `seq_no`、新数据连续、重传与 `DataPacketSpec` 约束见 **第 5.1 节** `on_link_ready`。
- **Host 接收**：共享接收缓冲、`on_packet_arrival` 中交付/入缓冲/丢弃语义见 **第 5.1 节** `on_packet_arrival`。
- **交换机**：`on_packet_arrival` 选路与队列满断言、`on_link_ready` 与 `request_link_ready` 的配合见 **第 5.2 节**。

---

## 4. 包的生命周期（DATA 包）

下列阶段划分用于对照 **第 3.5 节** 中的 `LINK_ARRIVE`、交换机入队与 `on_link_ready` 出队等事件，理解包在「链路上 / 交换机队列中 / 主机上」的位置。


| 阶段                | 含义                      | 说明                                                                |
| ----------------- | ----------------------- | ----------------------------------------------------------------- |
| `CREATED`         | 在源 `host` 被创建           | `Host` 在 `on_link_ready` 返回 `DataPacketSpec`，仿真器构造 `Packet` 并安排发送 |
| `ON_LINK`         | 在链路上传输                  | 对应 `LINK_ARRIVE` 事件尚未被处理；此时包不在任何节点                                |
| `AT_SWITCH`       | 到达交换机、尚未入队              | 正在执行 `on_packet_arrival` 或即将入队                                    |
| `IN_SWITCH_QUEUE` | 在交换机某输出端口队列中            | 已入队，等待 `on_link_ready` 被选中发出                                      |
| `AT_HOST`         | 到达目的 `host`，作为「当前包」正被处理 | 已调用 `on_packet_arrival(pkt, ctx)`，尚未交付或入缓冲                        |
| `IN_HOST_BUFFER`  | 在目的 `host` 的接收缓冲中       | 已通过 `add_packet_to_buffer` 写入缓冲                                   |
| `DELIVERED`       | 已交付应用层                  | 策略调用了 `deliver_packet` 且该包对应字节已计入已交付前缀                            |
| `DROPPED`         | 被丢弃                     | 策略/AQM、无合法转发、队列满、重复包、主机侧未交付且未入缓冲等（**无链路随机丢包**）                    |


- `CTRL` **控制包**：到达 host 后由 `on_packet_arrival`（CTRL） 处理，不进入接收缓冲或交付状态。
- 同一时刻一个包只处于一个阶段；仿真器通过 `packet_store` 与每包一条 `runtime`（阶段、队列位点、终端原因等）维护位置与生命周期。

---

## 5. 需要实现的接口

### 5.1 HostStrategy

每个 host 挂载一个 `HostStrategy` 实例，负责本 host 上所有流的发送与接收逻辑。

#### `on_sim_start`

- **调用时机**：**所有仿真事件开始推进之前**，对每个 host 策略实例各调用**一次**（早于任何 `on_flow_arrival` / `on_link_ready` 等）。
- **是否必须实现**：**必须**。
- **可做什么**：保存 `host_id`、上行 `LinkInfo`、`buffer_size_bytes`、`simulation_time_us`；预计算与静态拓扑相关的表结构。`Host` 在赛题保证下**恰有一条**上行链路，见 `init.link`。

**参数**

- `init`（`HostInitInfo`）：本 host 的静态快照，仅含以下字段：
  - `host_id`（`int`）：本 host 的节点 ID。
  - `link`（`LinkInfo`）：上行链路，字段为：
    - `link_id`（`LinkId`）：该链路 ID（经此链路发往对端即本 host 的唯一「端口」）。
    - `peer_node_id`（`int`）：对端节点 ID（即所连交换机）。
    - `bandwidth_gbps`（`float`）、`latency_us`（`float`）：链路带宽与传播时延。
  - `buffer_size_bytes`（`int`）：本 host **接收缓冲**总容量（字节），与 `topology.json` 中该节点的 `buffer_size_bytes` 一致，也与 `ctx.get_rx_buffer_remaining()` 所基于的总容量一致（运行期占用随交付/丢弃变化）。
  - `simulation_time_us`（`float`）：**全局**仿真时钟上界（微秒），与 `topology.json` 的 `global_config.simulation_time_us` 一致；所有节点 `on_sim_start` 中该值相同。可与 `on_flow_arrival` 中的 `deadline_us` 对照，用于 pacing、定时器范围或「临近上界」时的策略收尾；实际终止原因仍以评测输出中的 `termination_reason` 为准。

**返回值**

- 无（`None`）。

---

#### `on_flow_arrival`

- **调用时机**：某条流在仿真中开始（`FLOW_START`）时，在**该流的源** `host` 上调用**一次**；随后仿真器会为该 `host` 调度一次 `LINK_READY`。
- **是否必须实现**：**必须**。
- **可做什么**：登记新流元数据、初始化发送端状态；后续发送通常在 `on_link_ready` 中完成。

**参数**

- `flow_id`（`int`）：本条流的唯一标识，与流量表及数据包中的 `flow_id` 一致。
- `dst_node`（`int`）：该流的目的节点 ID（也只是一个 host）；流的源节点就是当前节点。
- `size_bytes`（`int`）：该流需传输的总字节数；接收端需交付满该字节数后流才计为完成。
- `priority`（`int`）：流优先级，用于评分加权（数值越大权重越高）。
- `deadline_us`（`float`）：该流的截止时间（**绝对**仿真时间，微秒）；超过则该流得分为 0。
- `ctx`（`HostContext`）：当前 host 的运行期 `API`（时间、接收缓冲、`request_link_ready` / 链路调度、定时器等）。

**返回值**

- 无。

---

#### `on_link_ready`

- **调用时机**：本 host **唯一出链路**空闲（事件 `LINK_READY`；`on_link_ready(ctx)` **无**端口参数）。
- **是否必须实现**：**必须**。
- **可做什么**：发送数据包（创建新数据包或者重传）或控制包，也可以选择不发任何包以控制发送速率。

**参数**

- `ctx`（`HostContext`）：当前 host 上下文。

**返回值**

- `None`：本周期不发送任何包。
- `DataPacketSpec`：描述一个待发送的 DATA 包（字段见第 6.1 节）。
- `ControlPacketSpec`：描述一个待发送的 `CTRL` 包（仅 `dst_node`、`custom`）；`Packet.src_node` 由仿真器填为当前 `host`，选手无需填写。

**注意**

- 若返回 `DataPacketSpec(flow_id, seq_no, payload_size)`：`flow_id` 对应的流必须是源节点为本 host 的流（在当前 host 上触发了 on_flow_arrival）；`seq_no` 为非负 `int`；`payload_size` 为正 `int` 且 **≤** `MAX_PAYLOAD`（1436）；`seq_no + payload_size` 不超过该流 `size_bytes`；新数据须按字节序连续发送，重传须是曾发送过的段（重传包的 `seq_no` 和 `payload_size` 需与同一个流已发送的某个数据包一致），否则框架调用 `assert`。
- 若返回 `ControlPacketSpec`：`dst_node` 须为拓扑中的合法节点 ID。
- 若返回 `DataPacketSpec` 或 `ControlPacketSpec`：发送完成后内核会在链路再次空闲时再次调度本 host 的 `LINK_READY`（与交换机出端口行为一致）。若返回 `None`，则链路在此刻保持空闲，内核**不会**再调度一次 `on_link_ready`，只有新流到达或者选手在其他回调中显式调用了 `ctx.request_link_ready()` 时才会再调度  `on_link_ready`。

---

#### `on_packet_arrival`

- **调用时机**：任意包到达本 host（**无** `input_port`）；用 `pkt.is_ctrl` 区分 DATA/CTRL。
- **是否必须实现**：**必须**。
- **可做什么**：DATA：交付/缓冲；CTRL：控制面逻辑（无交付/缓冲）。

**参数**：`pkt`（`PacketView`）、`ctx`（`HostContext`）。**返回值**：无。

**备注**：DATA 不交付且不入缓冲则丢弃。

---

#### `on_timer`

- **调用时机**：曾调用 `ctx.schedule_timer(delay_us, arg)` 后，在仿真时间到达 `now_us() + delay_us` 时调用，`arg` 与注册时一致。注册时 `delay_us` 须为数值且 **≥ 1.0**（微秒），见 **6.2**。
- **是否必须实现**：**可选**（基类默认空实现）。
- **可做什么**：RTO、pacing、周期性任务等。

**参数**

- `arg`（`object`）：注册定时器时传入的任意对象，常用 `tuple`（如 `("rto", flow_id)`）以区分用途。
- `ctx`（`HostContext`）：当前 host 上下文。

**返回值**

- 无（`None`）。

**约束**

- 无；`arg` 类型与含义由选手自定义并在 `on_timer` 内自行解析。

---

#### `on_sim_end`

- **调用时机**：**仿真结束后**，对每个 host 各调用一次（本地调试模式）。
- **是否必须实现**：**可选**。
- **可做什么**：打印统计、写调试日志；**不影响评分**。

**参数**

- `ctx`（`HostContext`）：当前 host 上下文。

**返回值**

- 无（`None`）。

**注意**

- **默认（线上测评）**时框架**不调用** `on_sim_end`；仅在使用 `--local` 本地调试时会调用。勿依赖 `on_sim_end` 做线上必要收尾逻辑。

---

### 5.2 SwitchStrategy

每个交换机挂载一个 `SwitchStrategy` 实例，负责各端口上的转发决策与出队调度。

#### `on_sim_start`

- **调用时机**：事件循环开始前，对每个交换机策略各调用**一次**。
- **是否必须实现**：**必须**。
- **可做什么**：保存 `switch_id`、所有直连 `LinkInfo`、`buffer_size_bytes`、`simulation_time_us`、按目的节点索引的最短路第一跳列表；初始化控制面或统计结构。

**参数**

- `init`（`SwitchInitInfo`）：本交换机的静态快照，字段为：
  - `switch_id`（`int`）：本交换机节点 ID。
  - `links`（`List[LinkInfo]`）：本节点**所有**直连链路，每条 `LinkInfo` 含义与 Host 侧相同（`link_id`、`peer_node_id`、`bandwidth_gbps`、`latency_us`）。出向端口即这些 `link_id`。
  - `next_hops`（`Dict[int, List[LinkId]]`）：**目的节点 ID → 第一跳链路 ID 列表**。与仿真器内核路由一致，为基于 `hop` 数的最短路径上的 `ECMP` 候选（列表中每个 `link_id` 均应出现在 `links` 中）。若策略需要与内核不同的路由，可自行维护路由表并在 `on_packet_arrival` 中返回任意**合法出链路** `link_id`。
  - `buffer_size_bytes`（`int`）：本交换机**每一个**输出端口 `FIFO` 队列的容量（字节），与 `topology.json` 中该节点的 `buffer_size_bytes` 一致；**各端口相互独立、容量相同**，均为该值（见第 3.2 节）。`ctx.get_port_usage(p).capacity_bytes` 对任意出端口 `p` 均等于此字段。
  - `simulation_time_us`（`float`）：与 `HostInitInfo.simulation_time_us` 含义相同（全拓扑一致）。

**返回值**

- 无（`None`）。

**约束**

- 无。

---

#### `on_link_ready`

- **调用时机**：本交换机上某条**出向链路** `output_port`（即 `LinkId`）在**当前事件时刻已空闲**（上一帧发送已完成、链路上无在传比特）时，仿真器调用本回调，让你决定**是否**从该端口发送**恰好一个**队列中的包，或**新产生**一条经该端口发出的 `CTRL`。与 `Host` 侧 `on_link_ready` 对称：**一次调用最多驱动一次发送**。具体触发来源包括：
  - **仿真初始化**：时间 0 上，对每个交换机的**每一条出向链路**各入队一次 `LINK_READY`，便于在首个业务包到达前从各端口发控制包或观察空队列。
  - **包刚入队且该出链路当时空闲**：某包经 `on_packet_arrival` 被转发并入某输出端口队列后，若该端口对应链路在**当前时刻**已空闲，仿真器会**立刻**再入队一次针对该链路的 `LINK_READY`（时间与当前处理事件相同），从而在包入队后尽快给你一次出队机会。
  - **本端口刚完成一次发送**：你在上一次 `on_link_ready` 中返回了有效的 `PacketId` 或 `ControlPacketSpec`，框架完成发送后，会在**该链路恢复空闲的时刻**（发送时隙结束、链路上不再占用）自动再入队一次针对**同一条出向链路**的 `LINK_READY`，用于连续排空同一端口的 `FIFO`。
  - **显式请求**：你在**同一交换机**的任意回调中调用了 `ctx.request_link_ready(output_port)`，且该 `output_port` 为合法出向链路、且该链路在**调用当时**已空闲，则仿真器会在**当前仿真时间**再入队一次该链路的 `LINK_READY`（通常在**当前回调返回后**与其它事件按时间顺序处理）。
- **是否必须实现**：**必须**。
- **可做什么**：从 `output_port` 对应队列中选取一个 `packet_id` 发出；或返回 `ControlPacketSpec` 在该端口发 `CTRL`；或返回 `None` 表示本次不发送。若队列里仍有包、或你稍后要再尝试发送，需理解下文：`request_link_ready` **与** `None` **返回值下的调度关系**。

**参数**

- `output_port`（`LinkId`）：`int`，本次 `LINK_READY` 事件所对应的**出向链路** `ID`（本题中端口与邻接链路一一对应，见第 3.2 节）；与该端口上的 `FIFO` 队列一一对应。
- `ctx`（`SwitchContext`）：本交换机运行期上下文。

**返回值**

- `None`：本周期不从该端口发送任何包。
- `PacketId`（`int`）：从该端口队列取出并发送该 id 对应包（`DATA` 或 `CTRL`）。
- `ControlPacketSpec(dst_node=..., custom=...)`：在该端口新发送一条 `CTRL`（字段含义见第 6.1 节；`src_node` 由仿真器填为当前交换机）。

**注意**

- 若返回 `PacketId`：该 id 必须**当前位于** `output_port` **对应端口的队列中**（可用 `ctx.get_port_queue_packet_ids` / `ctx.get_packet_view` 核对），否则框架断言失败。
- 若返回 `ControlPacketSpec`：由框架创建并发送 `CTRL`；`dst_node` 须为拓扑中的合法节点 ID。
- **为何需要** `ctx.request_link_ready(output_port)`  
  - 当本次 `on_link_ready` 返回 `PacketId` **或** `ControlPacketSpec` 时，框架在发送完成后会**自动**在链路再次空闲时调度下一次 `LINK_READY`，你通常**不必**再为该次发送手动调用 `request_link_ready`。  
  - 当本次 `on_link_ready` 返回 `None` 时，框架**不会**因为「同一端口队列里还有包」而自动再入队 `LINK_READY`：链路仍空闲，但没有新的调度事件，该端口会**一直等到**其它路径触发（例如又有包入队且当时链路空闲、或你在别处调用了 `request_link_ready`）。因此：  
    - 若你**暂时不想发**（如严格优先级调度、想等其它端口先清空、或本次未选中队头包），但**希望在同一仿真时刻或稍后链路仍空闲时再被问一次**，应在本次回调返回前调用 `ctx.request_link_ready(output_port)`（仅当该链路**当前已空闲**时才会入队成功；若链路正忙，下一次机会会由**发送完成**时的自动 `LINK_READY` 给出）。  
    - 这与 `Host` 侧「`on_link_ready` 返回 `None` 后需 `request_link_ready()` 才会再次触发」是同一类设计：**返回** `None` **表示放弃本轮发送权**；**是否再次调度**由框架的其它规则或你的显式请求决定。
- 若队列非空且你希望**连续排空**，常见写法是每次返回一个 `PacketId`，依赖发送完成后的自动 `LINK_READY`；若采用「本次返回 `None`、但队列仍有包」的策略，则必须配合 `request_link_ready`（或等待新包入队带来的触发），否则该端口可能长期不再收到 `on_link_ready`。

---

#### `on_packet_arrival`

- **调用时机**：**任意包**（`DATA` 或 `CTRL`）从入链路进入本交换机、完成本节点登记后、**尚未入输出队列**时调用。
- **是否必须实现**：**必须**。
- **可做什么**：选择出端口转发入队，或丢弃；可结合在 `on_sim_start` 中缓存的 `SwitchInitInfo.next_hops` 与 `ctx.get_port_usage` 等运行期信息，或完全依赖自建路由表。

**参数**

- `pkt`（`PacketView`）：到达本节点的包视图；`DATA` 与 `CTRL` 均会经过本回调（可用 `pkt.is_ctrl` 区分）。
- `input_port`（`LinkId`）：`int`，包从哪条**入向链路**进入本交换机（链路 `ID`）。
- `ctx`（`SwitchContext`）：本交换机运行期上下文（时间、各端口队列与占用、定时器等）。

**返回值**

- `Optional[LinkId]`：即 `None` 或某个 `int` 类型的出向 `link_id`。

**注意**

- 若返回 `None`：`DATA` 视为被策略丢弃（计入 `AQM` 类丢包统计）；`CTRL` 视为在本节点终止，**不**按丢包统计。
- 若返回**非** `None`：该值必须是**本交换机的一条出向** `link_id`（与 `SwitchInitInfo.links` 中某条的 `link_id` 一致，即仿真器邻接表中的出链路）；且对应端口队列剩余容量 **≥** `pkt.size`（字节），否则框架调用 `assert`；选手应事先用 `ctx.get_port_usage` 等判断。

---

#### `on_timer`

- **调用时机**：本交换机曾调用 `ctx.schedule_timer(delay_us, arg)`，到期后在本策略上触发。注册时 `delay_us` 须为数值且 **≥ 1.0**（微秒），见 **6.3**。
- **是否必须实现**：**可选**。
- **可做什么**：定时测量、拓扑老化、控制面逻辑等。

**参数**

- `arg`（`object`）：注册定时器时传入的对象。
- `ctx`（`SwitchContext`）：本交换机上下文。

**返回值**

- 无（`None`）。

**约束**

- 无；`arg` 含义由选手自定。

---

#### `on_sim_end`

- **调用时机**：仿真结束后，对每个交换机各调用一次（本地调试模式）。
- **是否必须实现**：**可选**。
- **可做什么**：调试与统计；**不参与评分**。

**参数**

- `ctx`（`SwitchContext`）：本交换机上下文。

**返回值**

- 无（`None`）。

**约束**

- **默认线上测评模式下不调用**；使用 `--local` 本地调试时会调用。

---

## 6. API 介绍

完整定义见 `src/sim_api.py`，此处为摘要。

### 6.1 类型与约定

- `PacketId`：整型，由仿真器分配，用于在队列与 API 中唯一标识一个包。
- `LinkId`：整型，物理链路唯一标识；从某节点经该 id 发往对端即一个「端口」。
- `DataPacketSpec(flow_id, seq_no, payload_size, custom=None)`：在 **Host** 的 `on_link_ready(ctx)` 中返回，描述要发送的一个 `DATA` 包。
- `ControlPacketSpec(dst_node, custom=None)`：在 Host 与交换机的 `on_link_ready` 中均可返回，描述要发送的一个 `CTRL` 包。包的 `src_node` 由仿真器自动按当前发送节点填入。
- `PacketView`：包的只读视图（Protocol）。仿真器传入的实为 `Packet`；除 `custom` 外均为只读（改写会报错）。`custom` 可整体赋值或修改内部字段（如 `pkt.custom["key"] = v`）。字段：`packet_id`, `flow_id`, `src_node`, `dst_node`, `seq_no`, `payload_size`, `is_ctrl`（若为 `True`，**则为控制包**），`custom`（可写），`size`（包在链路上的等效字节数）。`DATA` 的 `size = 64 + payload_size`，并满足总长不超过 `MTU=1500`（即 `payload_size ≤ MAX_PAYLOAD=1436`）；`CTRL` 的 `size` **固定为** `64`，`payload_size` **恒为** `0`。

### 6.2 HostContext（Host 策略运行期可用）


| 方法                                 | 说明                                                                                              |
| ---------------------------------- | ----------------------------------------------------------------------------------------------- |
| `now_us()`                         | 当前仿真时间（微秒）                                                                                      |
| `schedule_timer(delay_us, arg)`    | 注册定时器，在 `now_us() + delay_us` 触发 `on_timer(arg, ctx)`；`delay_us` 须为 `int`/`float` 且 **≥ 1.0**（微秒） |
| `request_link_ready()`             | Host 专用、**无参**：在唯一出链路空闲时再次触发 `on_link_ready`                                                    |
| `get_received_packets()`           | 接收缓冲中未交付的包视图列表（按缓冲顺序）                                                                           |
| `get_delivered_up_to(flow_id)`     | 该流已交付的字节位置（左闭右开）                                                                                |
| `add_packet_to_buffer(packet_id)`  | 将**当前到达**的 `DATA` 包加入接收缓冲；若已在缓冲中则无效果；若剩余空间不足则断言失败；选手应先调用 `get_rx_buffer_remaining()` 检查剩余空间是否足够 |
| `deliver_packet(packet_id)`        | 交付指定包（当前包或缓冲中的包），仅当前缀连续且不越界时推进前缀                                                                |
| `drop_packet_in_buffer(packet_id)` | 从接收缓冲丢弃指定包                                                                                      |
| `get_rx_buffer_remaining()`        | 接收缓冲剩余空间（字节）                                                                                    |


### 6.3 SwitchContext（交换机策略运行期可用）


| 方法                                       | 说明                                                                                           |
| ---------------------------------------- | -------------------------------------------------------------------------------------------- |
| `now_us()`                               | 当前仿真时间（微秒）                                                                                   |
| `get_port_usage(output_port)`            | 该端口队列已用字节与容量；`capacity_bytes` 恒等于 `SwitchInitInfo.buffer_size_bytes`（每端口独立同容量）               |
| `get_port_queue_packet_ids(output_port)` | 该端口队列中的 `packet_id` 列表（`FIFO` **顺序**）                                                        |
| `get_packet_view(packet_id)`             | 通过 packet_id 获取 PacketView；若包不在当前节点则返回 None                                                  |
| `drop_packet(output_port, packet_id)`    | 从该端口队列主动丢弃指定包                                                                                |
| `request_link_ready(output_port)`        | 请求在当前时间为该输出端口再调度一次 `LINK_READY`；仅当该端口合法且链路空闲时生效（用于本次 `on_link_ready` 返回 `None` 但希望该端口再次被调度时） |
| `schedule_timer(delay_us, arg)`          | 注册定时器，在 `now_us() + delay_us` 触发 `on_timer(arg, ctx)`；`delay_us` 须为 `int`/`float` 且 **≥ 1.0**（微秒） |


## 7. 参考策略

参考实现位于 `strategies/strategies_ecmp_reorder.py`，包含 `MyHostStrategy` 与 `MySwitchStrategy` 两部分。

- **策略简述**：交换机侧对同一目的地候选下一跳采用 per-packet ECMP 分流；接收端在 host 侧进行乱序缓冲与按序交付，利用多路径并行提升吞吐。
- **优点**：实现简洁、工程复杂度低；在多路径且丢包较少的场景中，通常可以较好利用链路并行能力。
- **缺点**：未实现 ACK/重传机制，出现丢包后恢复能力弱；缺少完善拥塞控制时，在高并发突发流量下完成率和稳定性会下降。

---

## 8. 运行与配置文件

### 8.1 命令行

```bash
# 推荐 Python 3.9+
python src/run.py --code <策略.py 或 .zip> [--output output/results.json] [--dataset <数据集目录或数据集集合目录>] [--log <输出目录>] [--event_log] [--timeout 600] [--local]
```

- **--code**：你的策略文件路径（`.py` 或包含策略 `.py` 的 `.zip`）。当传入 `.zip` 时，内部选择规则为：优先提取文件名为 `strategies_api.py` 的条目；若不存在则提取压缩包中的第一个 `.py`。
- **--output**：多数据集聚合后的评分结果 JSON 输出路径（默认 `output/results.json`）。
- **--dataset**：传入一个**目录**。若该目录下直接包含 `topology.json` 和 `traffic.csv`，则仅运行这个数据集（例如 `--dataset datasets/leaf-spine-32`）；否则将其视为**数据集集合目录**，仅检查其**一层子目录**中哪些目录同时包含这两个文件，并运行这些数据集（例如 `--dataset datasets`）。**不传则默认扫描当前工作目录下的 `datasets/`**。
- **--log**：单数据集详细结果与事件日志输出目录（默认 `output/`）。
- **--event_log**：开启详细事件日志（会导出 JSONL 事件日志，默认关闭以节省磁盘空间）。
- **--timeout**：真实时间限制（wall timeout，秒）。超过该时长仿真终止并对“已完成的流”计分（线上测评设置为 600s，即 10min）。
- **--local**：本地调试模式；**会**调用策略的 `on_sim_end`。**默认不加本参数即为线上测评模式**，不调用 `on_sim_end`。

**Docker 镜像（线上测评）**：镜像内仅打包仓库中的 `datasets_final/`，在容器里路径为 **`/app/datasets`**（与命令行默认扫描的 `datasets/` 目录名一致）。典型用法：

```bash
docker build -t my-python-app .
docker run --rm -v $(pwd)/output:/app/output -v $(pwd)/submit:/app/submit my-python-app --code ./submit/xxx.zip
```

上述命令等价于：默认 **线上测评**（不调用 `on_sim_end`），默认扫描 **`/app/datasets`** 下全部子数据集。若需在容器内本地调试并触发 `on_sim_end`，在参数末尾追加 **`--local`**。

输出 JSON 中的 `termination_reason` 可能取值：

- `wall_timeout`：真实时间超限终止（对应 `--timeout`）。
- `sim_time_limit`：仿真时间到达上限终止（由 `topology.json` 的 `global_config.simulation_time_us` 决定，单位微秒）。
- `event_queue_empty`：事件队列耗尽终止。
- `unknown`：未命中上述常见终止分类；通常表示既不是事件队列耗尽、也不是仿真时间上限或真实时间超限，建议结合结果与日志进一步排查。

> 注意：如果本地运行判题器报无法导入 `dataclasses` 或者 `Protocol` 之类的错误，请升级 python 版本（至少 python3.9）。

### 8.2 配置文件格式

位于datasets/目录下

- **topology.json**：`global_config.simulation_time_us`（仿真时长上限，**微秒**）、`nodes`（id, type, `buffer_size_bytes` 等）、`links`（id, src, dst, bandwidth_gbps, latency_us 等；字段以赛题数据为准）。其中对 **switch** 节点，`buffer_size_bytes` 表示**每个输出端口队列**的容量（字节），各端口独立、相同；对 **host** 节点表示接收缓冲总容量。
- **traffic.csv**：表头 `FlowID,SrcNode,DstNode,SizeBytes,StartTimeUs,Priority,DeadlineUs`，每行一条流；`StartTimeUs` / `DeadlineUs` 为**微秒**、相对仿真起点的**绝对时间**。

### 8.3 数据集与参数约定

**测评数据集参数范围**

- 节点规模：host + switch 不超过 `1000`。
- 链路带宽(`bandwidth_gbps`)：`1~100`Gbps。
- 单链路传播时延(`latency_us`)：`1μs~10ms`。
- 缓冲区(`buffer_size_bytes`)：`1KB~4MB`。
- 总流量：不超过 `1GB`。
- 流量合法性：所有流满足 `src != dst`，且 `SrcNode` / `DstNode` 均为 host。

**拓扑约束**

- 拓扑保证是**连通图**。
- 赛题数据保证无重边：任意两个节点之间**至多一条**物理链路（无平行多重链路）。
- JSON 中每条 `links` 元素有唯一 `id`；全双工由仿真器在链路两端分别维护发送占用。
- 每个 host 刚好只连接一个交换机。

---

## 9. 测评环境

- 测评环境以 **Docker 镜像** 方式提供与运行。
- 操作系统：`Alpine Linux v3.18`。
- Python 版本：`Python 3.11.4`。
- 单次仿真进程最大可用内存：`1 GB`。
- 仿真器运行时长限制：`10 min`。

---

## 10. 评分机制

### 单条流得分

- 若**未在仿真中完成**或**完成时间超过 deadline**，该流得分为 **0**。
- 否则，该流得分 = `priority` × min(1.0, `ideal_fct_us` / `actual_fct_us`)。

`ideal_fct_us` 表示「该流在理想条件下的完成时间下界」：仅考虑这一条流、且该流可占满源到目的的最小割带宽、传播时延取最短路径。

- `L` = 源到目的的最短传播时延（仅按链路 `latency_us` 求和）。
- `C` = 源到目的的最大流容量（字节/微秒），即最小割的总带宽。
- `wire_bytes = 流 payload 字节数 + ceil(流 payload 字节数 / MAX_PAYLOAD) × DATA_HEADER_BYTES`。
- `ideal_fct_us = L + wire_bytes / C`。

> 注意：线上测评时，限制运行时长 10min，超过此时间后，仿真直接终止，未完成的流记 0 分。

### 单数据集最终得分

- 先计算基准分：`base_score = min(100.0, 每条流得分之和/流权重之和×100.0)`。
- 再计算完成率：`completion_ratio = completed_flows / total_flows`。
- 最终分：`final_score = base_score × completion_ratio^2`。

其中 `actual_fct_us` = 流完成时刻 − 流开始时刻。当**已交付字节数**达到该流的 `size_bytes` 时，仿真器将该流标记为完成（策略某次调用 `deliver_packet` 推进了 `delivered_up_to` 至流总大小即触发）。

### 最终得分

线上测试包含多个数据集，取均分作为最终得分。

---

## 11. 对选手策略的限制与作弊判定

### 11.1 不允许的行为

- **不得**直接访问或修改仿真器内部对象（如 `Simulator`、`_packet_store`、`_hosts`、端口队列等），只能通过 `HostContext` / `SwitchContext` 的接口与仿真器交互。
- **不得**修改 `PacketView` 中除 `custom` 以外的字段（如 `packet_id`, `flow_id`, `seq_no` 等）；对它们赋值会触发 `AttributeError`。仅允许读写 `custom`（包括 `pkt.custom = {...}` 或 `pkt.custom["k"] = v`）。
- **不得**在策略中通过 `import` 或反射获取、调用仿真器内部模块（如 `simulator`、`config_loader` 的未公开 `API`），或读取拓扑/流量文件（如直接读 `topology.json` / `traffic.csv`）绕过仿真器。与本节点相关的**合法**静态拓扑由仿真器在 `on_sim_start(init)` 中注入（`HostInitInfo` / `SwitchInitInfo`）；若需**全图**或动态拓扑，须自行通过控制包交换与维护。

### 11.2 节点只能使用本地信息；禁止跨节点“共享内存”式作弊

仿真在**单一 Python 进程**中运行，每个 host / 交换机各有一个策略**实例**，但所有实例共用同一解释器。赛题在**网络语义**上仍要求：**每个节点仅代表一台独立设备，只能读写自己的本地信息**；节点之间**没有**共享内存，与真实分布式网络一致。

- **合法信息来源（对本节点而言）**：`on_sim_start(init)` 给出的**本节点**静态快照；本策略类实例上通过 `self` 维护的状态；以及运行期通过 `HostContext` / `SwitchContext` 与到达本节点的 `PacketView`（含 `custom`）所能获得的一切。不得假定能直接读取**其他节点**策略实例的内部状态。
- **明令禁止**：不得利用进程内共享，通过**模块级全局变量**、**在类对象上存放供所有实例共读写的可变状态**、**单例 / 可变缓存**、**向磁盘或固定路径写入再由其他节点回调里读回**等方式，在**不同节点的策略实例之间**传递本应在链路上用**包**传送的信息。原因：这相当于虚构了一条真实网络中不存在的**全局侧信道**，违背赛题模型，**按作弊处理**。
- **节点间如何交换信息**：任何需要让**其他节点**知道的内容，必须通过仿真规定的 `DATA` / `CTRL` 包在网络中发送（例如在 Host/交换机 `on_link_ready` 中返回 `DataPacketSpec` / `ControlPacketSpec`），由对端在 `on_packet_arrival` 中接收与解析。**不得**用上述全局/文件等方式在节点间“直接对表”，绕过发包语义。

---

## 12. FAQ

**Q：`get_packet_view(packet_id)` 返回 `None`？**  
A：表示该包**当前不在本交换机节点**（可能在链路上、其它节点或已被交付/丢弃）。仅当包在本交换机队列或正在 `on_packet_arrival` 处理时才会返回视图。

**Q：on_link_ready 里如何选包？**  
A：用 `ctx.get_port_queue_packet_ids(output_port)` 得到该端口队列的 `packet_id` 列表（`FIFO` **顺序**）；对需要查看内容的 `packet_id` 调用 `ctx.get_packet_view(packet_id)` 获取视图（可能为 `None`）；返回要发送的 `PacketId` 或 `None`。

**Q：on_link_ready 返回 None 后，如何让该端口再次被调度？**  
A：若本次不发送但希望该端口在链路空闲时再次触发一次 `on_link_ready`（例如队列仍有包、下次再选），可调用 `ctx.request_link_ready(output_port)`。仅当该端口合法且链路当前空闲时，会在当前时间入队一次 LINK_READY 事件。

**Q：接收端如何实现乱序重排？**  
A：在 `on_packet_arrival` 中对不能按序交付的包调用 `ctx.add_packet_to_buffer`；用 `ctx.get_received_packets()` 与 `ctx.get_delivered_up_to(flow_id)` 找出下一个按序可交付的包，循环调用 `ctx.deliver_packet` 直至无法推进。

**Q：端口队列和接收缓冲的占用按什么计算？**  
A：交换机端口队列与 host 接收缓冲/乱序缓冲都按包的 `size` 计费，即按**完整包大小**（包含 header）计算占用，不仅仅是 `payload_size`。同时，流完成判定与 `delivered_up_to` 仍按 payload 字节推进。

**Q：ideal FCT 会在运行时告诉策略吗？**  
A：评分器使用 ideal FCT 计分，但 Context API 未提供该值。若有需要，可根据流大小、拓扑与带宽自行估算下界用于策略内部逻辑。

**Q：选路时如何得到下一跳？**  
A：在 `on_sim_start(self, init: SwitchInitInfo)` 中读取 `init.next_hops`：键为目的节点 ID，值为 hop 最短路第一跳的 `link_id` 列表（与内核路由一致，可多候选做 ECMP）。若目的为直连邻居，也可在 `init.links` 里找 `peer_node_id == dst` 的 `link_id`。自定义路由可自建表后返回任意**合法出链路** `link_id`（须属于 `init.links`）。需保证所选端口队列有足够空间才能成功入队。

**Q：策略可以访问拓扑结构吗？**  
A：**本节点静态邻接**由 `on_sim_start(init)` 提供：`Host` 为 `init.link`，交换机为 `init.links`（及 `init.next_hops`）。不得直接读 `topology.json`。若需**全局**拓扑，须自行用控制包在节点间交换信息并维护。

---

